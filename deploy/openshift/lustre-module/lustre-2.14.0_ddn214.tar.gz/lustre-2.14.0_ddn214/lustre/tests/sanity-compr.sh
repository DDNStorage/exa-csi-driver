#!/bin/bash
#
# Run select tests by setting ONLY, or as arguments to the script.
# Skip specific tests by setting EXCEPT.
#

set -e

ONLY=${ONLY:-"$*"}

LUSTRE=${LUSTRE:-$(dirname $0)/..}
. $LUSTRE/tests/test-framework.sh
init_test_env "$@"
init_logging

# bug number for skipped test:
ALWAYS_EXCEPT="$SANITY_COMPR_EXCEPT "

always_except EX-10077 1081

if [[ $(uname -m) = aarch64 ]]; then
	# 64k client rounds data size up to page size and all these 64k pages
	# are saved on the server. This changes results so next tests fail
	always_except EX-10582 1007 1008
fi

build_test_filter

FAIL_ON_ERROR=false

check_and_setup_lustre

(( $MDS1_VERSION >= $(version_code 2.14.0-ddn93) )) ||
	skip "need MDS >= 2.14.0-ddn93 for compress layout support"

compression_enabled || skip "compression is disabled ($(uname -a))"

# $RUNAS_ID may get set incorrectly somewhere else
if [[ $UID -eq 0 && $RUNAS_ID -eq 0 ]]; then
	skip_env "\$RUNAS_ID set to 0, but \$UID is also 0!" && exit
fi
check_runas_id $RUNAS_ID $RUNAS_GID $RUNAS

DIRECTIO=${DIRECTIO:-directio}
RAMKB=$(awk '/MemTotal:/ { print $2 }' /proc/meminfo)
MAX_THREADS=${MAX_THREADS:-20}
if [ -z "$THREADS" ]; then
	THREADS=$((RAMKB / 16384))
	[ $THREADS -gt $MAX_THREADS ] && THREADS=$MAX_THREADS
fi
SIZE=${SIZE:-$((RAMKB * 2))}

save_layout_restore_at_exit $MOUNT
# Set file system with different layout
COMPR_EXTRA_LAYOUT=${COMPR_EXTRA_LAYOUT:-"-E EOF -c 1"}
$LFS setstripe $COMPR_EXTRA_LAYOUT $MOUNT
ALWAYS_EXCEPT_SAVE=$ALWAYS_EXCEPT

test_1a() {
	(( $MDS1_VERSION >= $(version_code 2.14.0-ddn132) )) ||
		skip "need MDS > 2.14.0-ddn131-15-g3e1dd9d6ae for comp add"

	local tf=$DIR/$tfile
	stack_trap "rm -f $tf"

	$LFS setstripe -E1M $tf || error "setstripe failed"
	$LFS setstripe -Eeof --component-add -Z gzip $tf ||
		error "add compression component failed"

	$LFS getstripe -I2 --compr-type $tf | grep "gzip" || {
		$LFS getstripe -v $tf
		error "added component should be a compression one"
	}
}
run_test 1a "add a compression component"

test_sanity()
{
	[[ "$SLOW" == "yes" ]] || skip_env "Sanity with CSDC is slow"

	always_except LU-16928 56wb
	always_except LU-16904 906
	always_except EX-7938 100
	always_except EX-8927 430c

	[[ -n "$SANITYN_ONLY" && -z "$SANITY_ONLY" ]] && return 0

	SANITY_EXCEPT=$ALWAYS_EXCEPT ONLY=$SANITY_ONLY bash sanity.sh
	return 0
}
run_test sanity "Run sanity with PFL layout"

test_sanityn()
{
	[[ "$SLOW" == "yes" ]] || skip_env "Sanityn with CSDC is slow"
	[[ -n "$SANITY_ONLY" && -z "$SANITYN_ONLY" ]] && return 0

	SANITYN_EXCEPT=$ALWAYS_EXCEPT ONLY=$SANITYN_ONLY bash sanityn.sh
	return 0
}
run_test sanityn "Run sanityn with PFL layout"

# Sets new value to extents_dense.
# Restores the orignal value with stack_trap
check_and_set_extents_dense() {
	local value=$1
	local dense=$(do_facet ost1 lctl get_param -n \
			      osd*.*OST0000*.extents_dense)

	[[ -n $dense ]] || skip "no dense writes supported"

	do_nodes $osts $LCTL set_param osd*.*.extents_dense=$value ||
		error "cannot enable dense extent allocation"
	stack_trap "do_nodes $osts $LCTL set_param osd*.*.extents_dense=$dense"
}

test_1000a() {
	local filefrag_op=$(filefrag -l 2>&1 | grep "invalid option")
	[[ -z "$filefrag_op" ]] || skip_env "filefrag missing logical ordering"

	local blocks=128
	local osts=$(comma_list $(osts_nodes))

	check_and_set_extents_dense 0
	local tf=$DIR/$tfile
	stack_trap "rm -f $tf"
	log "create file with dense=0"

	$LFS setstripe -c 1 -i 0 $tf
	for ((i=0; i<$blocks; i++)); do
		dd if=/dev/zero of=$tf bs=32k seek=$((i*2)) count=1 \
			oflag=direct >&/dev/null conv=notrunc ||
				error "can't dd (sparse)"
	done
	filefrag -sv $tf
	local nonr=0
	while read EX LS LE PS PE LEN DEV FLAGS; do
		[[ "$EX" == "ext:" || "$EX" =~ "File" ]] && continue
		[[ "$EX" == "0:" ]] && PREV=${PE%:} && ((nonr+=1)) && continue
		(( ${PS%%.*} == PREV + 1 )) || ((nonr+=1))
		PREV=${PE%:}
	done < <(filefrag -v $tf)
	(( nonr > 0 )) || error "no extents?"
	rm -f $tf
	wait_delete_completed

	do_nodes $osts $LCTL set_param osd*.*.extents_dense=1 ||
		error "cannot enable dense extent allocation"
	#define OBD_FAIL_OSC_MARK_COMPRESSED    0x419
	$LCTL set_param fail_loc=0x419
	log "create file with dense=1"

	$LFS setstripe -c 1 -i 0 $tf
	for ((i=0; i<$blocks; i++)); do
		dd if=/dev/zero of=$tf bs=32k seek=$((i*2)) count=1 \
			oflag=direct conv=notrunc >&/dev/null ||
				error "can't dd (dense)"
	done
	filefrag -sv $tf
	local nr=0
	while read EX LS LE PS PE LEN DEV FLAGS; do
		[[ "$EX" == "ext:" || "$EX" =~ "File" ]] && continue
		[[ "$EX" == "0:" ]] && PREV=${PE%:} && ((nr+=1)) && continue
		(( ${PS%%.*} == PREV + 1 )) || ((nr+=1))
		PREV=${PE%:}
	done < <(filefrag -v $tf)
	(( nr > 0 )) || error "no extents?"

	echo "dense ($nr) should have fewer extents ($nonr)"
	(( (nonr / nr) > 3 )) ||
		error "dense ($nr) should have less extents ($nonr)"
	$LCTL set_param fail_loc=0

	local tmpfile=$(mktemp)
	stack_trap "rm -f $tmpfile"
	echo "generate temp file $tmpfile"
	dd if=/dev/urandom of=$tmpfile bs=32k count=$((blocks*2)) iflag=fullblock ||
		error "can't generate temporary file"
	dd if=$tmpfile of=$tf bs=32k conv=notrunc
	cancel_lru_locks osc

	stop ost1 || error "(2) Fail to stop ost1"
	run_e2fsck $(facet_host ost1) $(ostdevname 1) "-y" ||
		error "(3) Fail to run e2fsck error"
	start ost1 $(ostdevname 1) $OST_MOUNT_OPTS ||
		error "(4) Fail to start ost1"

	cmp $tmpfile $tf || error "data mismatch"
}
run_test 1000a "compressed vs uncompressed allocation"

test_1000b() {
	[[ "$ost1_FSTYPE" == "ldiskfs" ]] || skip "need ldiskfs backend"
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn122) )) ||
		skip "Need MDS >= 2.14.0-ddn121-12-g7731c7fc74 for partial read"
	local osts=$(comma_list $(osts_nodes))

	check_and_set_extents_dense 1

#define OBD_FAIL_OSD_MARK_COMPRESSED	 	0x2302
	do_nodes $osts $LCTL set_param fail_loc=0x2302 ||
		error "cannot force dense writes"
	stack_trap "do_nodes $osts $LCTL set_param fail_loc=0"

	$LCTL set_param llite.*.enable_compression=0
	stack_trap "$LCTL set_param llite.*.enable_compression=1"

	local testfile=$DIR/$tfile.fsxfile
	local fsx_size=$SIZE
	local fsx_count=${FSX_COUNT:-1000}
	local space=$(df -P $MOUNT | tail -n 1 | awk '{ print $4 }')

	(( $space >= $fsx_size )) || fsx_size=$((space * 3 / 4))
	local fsx_seed=${FSX_SEED:-$RANDOM}

	check_set_fallocate_or_skip

	rm -f $testfile
	$LFS setstripe -E eof -c -1 -Z none $testfile ||
		error "'setstripe $fsx_layout $testfile' failed"
	stack_trap "rm -f $testfile"

	debugsave
	stack_trap "debugrestore"
	$LCTL set_param debug=0

	CMD="$FSX -c 50 -p 1000 -S $fsx_seed -P $TMP -l $fsx_size \
	     -N $((fsx_count * 100)) $FSXOPT $testfile"
	echo "Using: $CMD"
	$CMD || error "fsx failed"

	return 0
}
run_test 1000b "verify dense writes with fsx on ldiskfs"

test_1000c() {
	local tf=$DIR/$tfile
	local ffout=$(mktemp)
	local chsz=64

	local filefrag_op=$(filefrag -l 2>&1 | grep "invalid option")
	[[ -z "$filefrag_op" ]] || skip_env "filefrag missing logical ordering"
	[[ "$ost1_FSTYPE" == "ldiskfs" ]] || skip "need ldiskfs backend"

	stack_trap "rm -rf $tf $ffout "

	local dense=$(do_facet ost1 lctl get_param -n \
			      osd*.*OST0000*.extents_dense)
	[[ -n $dense ]] || skip "no dense writes supported"

	local osts=$(comma_list $(osts_nodes))
	do_nodes $osts $LCTL set_param osd*.*.extents_dense=1 ||
		error "cannot enable dense extent allocation"
	stack_trap "do_nodes $osts $LCTL set_param osd*.*.extents_dense=$dense"

	wait_delete_completed

	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4 --compress-chunk=$chsz $tf ||
		error "can't setstripe"
	dd if=/dev/zero of=$tf bs=${chsz}k count=1000 conv=fdatasync ||
		error "can't dd"

	# filefrag doesn't support compressed files yet
	# so take extent map from direct mount
	# and count real physical extents
	local ostdev=$(ostdevname 1)
	local fid=($($LFS getstripe $tf | grep 0x))
	fid=${fid[6]##[}
	fid=${fid%%]}
	local seq=${fid//:*/}
	seq=${seq##0x}
	local oid=${fid#0x*:}
	oid=${oid%%:*}
	local objpath="O/$seq/d$(($oid % 32))/${oid#0x}"

	do_facet ost1 "$DEBUGFS -c -R 'filefrag -v $objpath' $ostdev" >$ffout
	[[ -s $ffout ]] || error "no filefrag info"
	local nonr=$(cat $ffout | awk '/[0-9]+[ \t]+[0-9]+[ \t]+[0-9]+/{print}' |
		sort -n -k3 | awk '{if($3!=prev){print};prev=$3+$4}' | wc -l)
	(( nonr >= 1 && nonr < 100 )) || {
		cat $ffout
		error "too many extents - $nonr"
	}
}
run_test 1000c "test dense writes on a compressed file"

test_1000d() {
	(( $MDS1_VERSION >= $(version_code 2.14.0-ddn171) )) ||
		skip "need MDS >= 2.14.0-ddn171"
	(( OSTCOUNT >= 2 )) || skip_env "needs >= 2 OSTs"

	local tf=$DIR/$tfile
	stack_trap "rm -f $tf*"
	[[ -z "$LFS_SETSTRIPE_COMPR_OK" ]] || compr_type="gzip"

	# setstripe parent directory with compression parameters
	$LFS setstripe -Z lz4 --compress-level=9 --compress-chunk=128 $DIR ||
		error "set compression template on $DIR failed"
	local dchunk=$($LFS getstripe --compress-chunk $DIR)

	# touch a file
	touch $tf-1 || error "touch $tf-1 failed"
	compr_type=$($LFS getstripe -I1 --compr-type $tf-1)
	compr_lvl=$($LFS getstripe -I1 --compr-level $tf-1)
	compr_chunk=$($LFS getstripe -I1 --compr-chunk $tf-1)
	[[ "$compr_type" == "lz4" && $compr_lvl == 9 && $compr_chunk == $dchunk ]] || {
		$LFS getstripe -v $tf-1
		error "touch $tf-1 didn't inherit compression from parent"
	}

	# setstripe plain file
	$LFS setstripe -c1 -i1 $tf-2 || error "setstripe $tf-2 failed"
	stripe_cnt=$($LFS getstripe -I1 -c $tf-2)
	stripe_off=$($LFS getstripe -I1 -i $tf-2)
	[[ $stripe_cnt == 1 && $stripe_off == 1 ]] || {
		$LFS getstripe -v $tf-2
		error "setstripe $tf-2 didn't correctly set stripe info"
	}
	compr_type=$($LFS getstripe -I1 --compr-type $tf-2)
	compr_lvl=$($LFS getstripe -I1 --compr-level $tf-2)
	compr_chunk=$($LFS getstripe -I1 --compr-chunk $tf-2)
	[[ "$compr_type" == "lz4" && $compr_lvl == 9 && $compr_chunk == $dchunk ]] || {
		$LFS getstripe -v $tf-2
		error "setstripe $tf-2 didn't inherit compression from parent"
	}

	# setstripe PFL w/o compression
	$LFS setstripe -Eeof $tf-3 || error "setstripe $tf-3 failed"
	compr_type=$($LFS getstripe -I1 --compr-type $tf-3)
	compr_lvl=$($LFS getstripe -I1 --compr-level $tf-3)
	compr_chunk=$($LFS getstripe -I1 --compr-chunk $tf-3)
	[[ "$compr_type" == "lz4" && $compr_lvl == 9 && $compr_chunk == $dchunk ]] || {
		$LFS getstripe -v $tf-3
		error "setstripe $tf-3 didn't inherit compression from parent"
	}

	# setstripe PFL w/ compression
	$LFS setstripe -E1M -E2M -Z gzip:4 --compress-chunk=64 -E4M \
		-Eeof -Z none $tf-4 || error "setstripe $tf-4 failed"
	local fchunk=$($LFS getstripe -I3 --compress-chunk  $tf-4)
	# 1st component
	compr_type=$($LFS getstripe -I1 --compr-type $tf-4)
	compr_lvl=$($LFS getstripe -I1 --compr-level $tf-4)
	compr_chunk=$($LFS getstripe -I1 --compr-chunk $tf-4)
	[[ "$compr_type" == "lz4" && $compr_lvl == 9 && $compr_chunk == $dchunk ]] || {
		$LFS getstripe -v -I1 $tf-4
		error "$tf-4 1st component didn't inherit compression from parent"
	}
	# 2nd component
	compr_type=$($LFS getstripe -I2 --compr-type $tf-4)
	compr_lvl=$($LFS getstripe -I2 --compr-level $tf-4)
	compr_chunk=$($LFS getstripe -I2 --compr-chunk $tf-4)
	[[ "$compr_type" == "gzip" && $compr_lvl == 4 && $compr_chunk == $fchunk ]] || {
		$LFS getstripe -v -I2 $tf-4
		error "$tf-4 2nd component didn't set its own compression"
	}
	# 3rd component
	compr_type=$($LFS getstripe -I3 --compr-type $tf-4)
	compr_lvl=$($LFS getstripe -I3 --compr-level $tf-4)
	compr_chunk=$($LFS getstripe -I3 --compr-chunk $tf-4)
	[[ "$compr_type" == "gzip" && $compr_lvl == 4 && $compr_chunk == $fchunk ]] || {
		$LFS getstripe -v -I3 $tf-4
		error "$tf-5 3rd component didn't inherit compression from its 2nd component"
	}
	# 4th component
	compr_type=$($LFS getstripe -I4 --compr-type $tf-4)
	[[ -z $compr_type ]] || {
		$LFS getstripe -v -I4 $tf-4
		error "$tf-4 4th component shouldn't set compression"
	}

	# setstripe PFL w/ only -Z none
	$LFS setstripe -E1M -E2M -Z none -Eeof $tf-5 ||
		error "setstripe $tf-5 failed"
	# 1st component
	compr_type=$($LFS getstripe -I1 --compr-type $tf-5)
	compr_lvl=$($LFS getstripe -I1 --compr-level $tf-5)
	compr_chunk=$($LFS getstripe -I1 --compr-chunk $tf-5)
	[[ "$compr_type" == "lz4" && $compr_lvl == 9 && $compr_chunk == $dchunk ]] || {
		$LFS getstripe -v -I1 $tf-5
		error "$tf-5 1st component didn't inherit compression from parent"
	}
	# 2nd component
	compr_type=$($LFS getstripe -I2 --compr-type $tf-5)
	[[ -z $compr_type ]] || {
		$LFS getstripe -v -I2 $tf-5
		error "$tf-5 2nd component shouldn't set compression"
	}
	# 3rd component
	compr_type=$($LFS getstripe -I3 --compr-type $tf-5)
	[[ -z $compr_type ]] || {
		$LFS getstripe -v -I3 $tf-5
		error "$tf-5 3rd component shouldn't set compression"
	}

	#setstripe PFL setting 1st component with -Z none
	$LFS setstripe -E1M -Z none -Eeof $tf-6 ||
		error "setstripe $tf-6 failed"
	# 1st component
	compr_type=$($LFS getstripe -I1 --compr-type $tf-6)
	[[ -z $compr_type ]] || {
		$LFS getstripe -v -I1 $tf-6
		error "$tf-6 1st component shouldn't set compression"
	}
	# 2nd component
	compr_type=$($LFS getstripe -I2 --compr-type $tf-6)
	[[ -z $compr_type ]] || {
		$LFS getstripe -v -I2 $tf-6
		error "$tf-6 2nd component shouldn't set compression"
	}
}
run_test 1000d "inherit compression from parent dir"

round_up_to_page() {
	local size_bytes=$1
	local page_size=$2
	local result

	result=$(awk -v size="$size_bytes" -v page_size="$page_size" \
		 'BEGIN {
			result = size / page_size
			rounded_result = int(result) + (result != int(result))
			print rounded_result * page_size
		 }')

    	echo "$result"
}

check_compr_read_counters() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn152) )) || return
	# XXXX until counters are fixed
	return

	local stats_fsize=$1	# File size from stats tool
	local dd_bs=$2		# Block size from dd tool
	local chunksize=128
	local output
	# For check bytes raw
	local rb_raw		# Read byte RAW from obdfilter.*.stats_compr
	local wb_raw		# Write byte RAW from osc.*.stats_compr
	# For check chunks
	local chunk_cnt 	# Count the number of chunks based on the fsize
	local rc_compr		# Read compr chunks from obdfilter.*.stats_compr
	local rc_incomp		# Read incompr chunks from obdfilter.*.stats_compr
	local total_chunk	# Total count chunks from read
	# For check bytes compr
	local wb_compr		# Write byte compr from osc.*.stats_compr
	local wb_incompr	# Write byte incompr from osc.*.stats_compr
	local rb_compr		# Read byte compr from obdfilter.*.stats_compr
	local rb_incompr	# Read byte incompr from obdfilter.*.stats_compr

	# For debug:
	do_facet ost1 $LCTL get_param obdfilter.$FSNAME-OST0000*.stats_compr
	$LCTL get_param osc.$FSNAME-OST0000*.stats_compr

	output=$(do_facet ost1 \
		 $LCTL get_param obdfilter.$FSNAME-OST0000*.stats_compr)

	# Check chunks:
	# Count the number of chunks and do +1 for rounding (if necessary)
	chunk_cnt=$(awk -v fsize="$stats_fsize" -v bs="$dd_bs" \
			'BEGIN { print int((fsize / (bs * 1024)) + 0.999) }')
	rc_compr=$(echo "$output" | awk '/compr_chunks_read/ { print $2 }' |
		   head -n 1)
	rc_incomp=$(echo "$output" | awk '/incompr_chunks_read/ { print $2 }' |
		    head -n 1)
	rc_compr=${rc_compr:-0}
	rc_incomp=${rc_incomp:-0}

	total_chunk=$(($rc_compr + $rc_incomp))
	(( $chunk_cnt == $total_chunk )) ||
	 	error "expected compr_chunks_read value '$chunk_cnt', got '$total_chunk'"

	# Check bytes compr:
	wb_compr=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		   awk '/write_bytes_compr:/ { print $2 }')
	wb_incompr=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		     awk '/write_bytes_incompr:/ { print $2 }')

	rb_compr=$(echo "$output" | awk '/compr_bytes_read/ { print $7 }' |
		   head -n 1)
	rb_incompr=$(echo "$output" | awk '/incompr_bytes_read/ { print $7 }')
	rb_compr=${rb_compr:-0}
	rb_incompr=${rb_incompr:-0}

	# We must align the all sizes to the page size due to the nature
	# of data transfer via LNET
	wb_compr=$(round_up_to_page "$wb_compr" "$PAGE_SIZE")
	rb_compr=$(round_up_to_page "$rb_compr" "$PAGE_SIZE")
	rb_compr=$(($rb_compr / ($chunksize / $dd_bs)))
	rb_compr=$(round_up_to_page "$rb_compr" "$PAGE_SIZE")
	# rb_compr=$(($rb_compr + $rb_incompr))

	(( $wb_compr == $rb_compr )) ||
	 	error "expected compr_bytes_read value "$wb_compr", got '$rb_compr'"

	(( $wb_incompr == $rb_incompr )) ||
	 	error "expected incompr_bytes_read value "$wb_incompr", got '$rb_incompr'"

	# Check RAW size:
	rb_raw=$(echo "$output" |  awk '/compr_bytes_read_raw/ { print $7 }')
	wb_raw=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_raw:/ { print $2 }')
	rb_raw=${rb_raw:-0}
	wb_raw=${wb_raw:-0}

	wb_raw=$(round_up_to_page "$wb_raw" "$PAGE_SIZE")
	rb_raw=$(round_up_to_page "$rb_raw" "$PAGE_SIZE")
	rb_raw=$(($rb_raw / ($chunksize / $dd_bs)))
	rb_raw=$(round_up_to_page "$rb_raw" "$PAGE_SIZE")
	rb_raw=$(($rb_raw + $rb_incompr))

	# FIXME:
	# We need to understand where the difference of 12288 bytes (3 PAGE)
	# comes from, and where we are not collecting them
	echo "wb_raw=$wb_raw rb_raw=$rb_raw"
	awk -v wb_raw="$wb_compr" -v rb_raw="$rb_raw" \
		'BEGIN {if ((diff = (wb_raw - rb_raw) / wb_raw * 100) > 1) exit 1}'
	(( $? == 0 )) ||
		error "diff between write raw size and read raw size more than 1%"
}

test_1001() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn122) )) ||
		skip "Need MDS >= 2.14.0-ddn121-12-g7731c7fc74 for partial read"

	local tf=$DIR/$tfile
	# We read from $tfile to this
	local tf_copy=$DIR/$tfile.copy
	# Larger than arm page size
	local chunksize=128
	local read_ahead_mb
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf
	local file_size
	local tmp_bs=16

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		echo "bunzip2 is not installed, skip it"
		return 0
	fi

	# Fail test if source size changes so we catch this
	# Source should be a few MiB in size
	$CHECKSTAT -s 14625450 $source || error "checkstat wrong size"

	stack_trap "rm -f $tf $tf_copy"

	# Clear OSC counters
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn128) )) &&
		$LCTL set_param osc.*.stats_compr=0
	# Simple compressed layout
	$LFS setstripe -i 0 -c 1 -E -1 \
		       -Z lz4:0 --compress-chunk=$chunksize $tf ||
			error "set a compress component in $tf failed"

	# Create file and verify - trivial
	#FIXME: We use O_DIRECT here to avoid RPC tearing which can create
	# read-modify-writes on the server, which aren't supported yet
	# We will remove this once read-modify-write is supported
	dd if=$source bs=${chunksize}K of=$tf oflag=direct ||
		error "(0) dd failed"
	cmp -bl $source $tf || error "(1) cmp failed"
	flush_and_compare $source $tf "(2)"

	# Copy from compressed to a non-compressed file
	dd if=$tf bs=4K of=$tf_copy conv=notrunc || error "(3) dd failed"
	flush_and_compare $tf $tf_copy "(4)"
	flush_and_compare $source $tf_copy "(5)"

	# Disable readahead so reads are not expanded to full chinks
	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	$LCTL set_param llite.*.max_read_ahead_mb=0
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb" EXIT
	rm -f $tf_copy

	(( $OST1_VERSION >= $(version_code 2.14.0-ddn152) )) &&
		do_facet ost1 $LCTL \
			 set_param -n obdfilter.$FSNAME-OST0000*.stats_compr=0

	# Copy from compressed to a non-compressed file with readahead disabled
	dd if=$tf bs="$tmp_bs"K of=$tf_copy conv=notrunc || error "(6) dd failed"

	# there should be no difference in size between the two files
	file_size=$(stat $tf | awk '/Size:/ { print $2 }')
	flush_and_compare $tf $tf_copy "(7)"
	flush_and_compare $source $tf_copy "(8)"
	check_compr_read_counters $file_size $tmp_bs
	rm -f $tf_copy
	# Same copy with larger size
	dd if=$tf bs=$((chunksize * 3/2))K of=$tf_copy conv=notrunc ||
		error "(9) dd failed"
	flush_and_compare $tf $tf_copy "(10)"
	flush_and_compare $source $tf_copy "(11)"

	# Same copy, but starting at non-zero offset
	# NB: In order to start at offset, we write in to an already existing
	# copy.  This isn't perfect, but it still catches lots of cases
	dd if=$tf bs=$((chunksize * 3/2))K seek=1 skip=1 of=$tf_copy conv=notrunc ||
		error "(12) dd failed"
	flush_and_compare $tf $tf_copy "(13)"
	flush_and_compare $source $tf_copy "(14)"

	rm -f $tf_copy
	# Explicit tests of partial page reads
	dd if=$tf bs=$((PAGE_SIZE * 2 - 1024)) of=$tf_copy conv=notrunc ||
		error "(15) dd failed"
	flush_and_compare $tf $tf_copy "(16)"
	flush_and_compare $source $tf_copy "(17)"

	# Partial page read starting at non-zero offset
	# NB: In order to start at offset, we write in to an already existing
	# copy.  This isn't perfect, but it still catches lots of cases
	dd if=$tf bs=$((PAGE_SIZE * 2 - 1024)) seek=10 skip=10 of=$tf_copy conv=notrunc ||
		error "(18) dd failed"
	flush_and_compare $tf $tf_copy "(19)"
	flush_and_compare $source $tf_copy "(20)"

	# There should be many smaller read RPCs
	$LCTL get_param osc.*.rpc_stats
}
run_test 1001 "test partial chunk reads"

test_1002() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn122) )) ||
		skip "Need MDS >= 2.14.0-ddn121-12-g7731c7fc74 for partial read"

	local tf=$DIR/$tfile
	# Larger than arm page size
	local chunksize=128
	local read_ahead_mb
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		echo "bunzip2 is not installed, skip it"
		return 0
	fi

	# Fail test if source size changes so we catch this
	# Source should be a few MiB in size
	$CHECKSTAT -s 14625450 $source || error "checkstat wrong size"

	stack_trap "rm -f $tf"

	# Disable readahead so reads are not expanded to full chinks
	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	$LCTL set_param llite.*.max_read_ahead_mb=0
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb" EXIT

	# Simple compressed layout
	$LFS setstripe -E -1 -Z lz4:0 --compress-chunk=$chunksize $tf ||
		error "set a compress component in $tf failed"

	# These tests will deliberately create unusual files, using the sample
	# hdf5 file as a reference, but cannot compare to it because they
	# copy only part of it.  So all of them will also create an identical
	# uncompressed file to compare against.
	# Create the simplest possible example of a file with an incomplete
	# chunk, just 4K at the beginning (this won't be compressed, but it's
	# still a valid test)
	dd if=$source bs=4K of=$tf count=1 || error "(0) dd failed"
	dd if=$source bs=4K of=$tf.2 count=1 || error "(1) dd failed"
	sync

	cmp -bl $tf $tf.2 || error "(2) cmp failed"
	flush_and_compare $tf $tf.2 "(3)"

	# 16K - this will be compressed
	dd if=$source bs=16K of=$tf count=1 || error "(4) dd failed"
	dd if=$source bs=16K of=$tf.2 count=1 || error "(5) dd failed"
	sync

	cmp -bl $tf $tf.2 || error "(6) cmp failed"
	flush_and_compare $tf $tf.2 "(7)"

	# OK, now we're going to create a complete compressed chunk further
	# along in the file
	dd if=$source bs=128K count=1 skip=1 seek=1 conv=notrunc of=$tf ||
		error "(8) dd failed"
	dd if=$source bs=128K count=1 skip=1 seek=1 conv=notrunc of=$tf.2 ||
		error "(9) dd failed"
	sync

	cmp -bl $tf $tf.2 || error "(10) cmp failed"
	flush_and_compare $tf $tf.2 "(11)"

	# OK, now we're going to add another incomplete chunk after those
	# two - starting in the third chunk, ie, offset of 256K
	dd if=$source bs=64K count=1 skip=4 seek=4 conv=notrunc of=$tf ||
		error "(12) dd failed"
	dd if=$source bs=64K count=1 skip=4 seek=4 conv=notrunc of=$tf.2 ||
		error "(13) dd failed"
	sync

	cmp -bl $tf $tf.2 || error "(14) cmp failed"
	flush_and_compare $tf $tf.2 "(15)"

	# And now we're going to add a chunk that doesn't start at offset 0,
	# so it won't be compressed.  This is the fourth chunk, so starts at
	# 384K.  So we'll start at 448K
	dd if=$source bs=64K count=1 skip=7 seek=7 conv=notrunc of=$tf ||
		error "(16) dd failed"
	dd if=$source bs=64K count=1 skip=7 seek=7 conv=notrunc of=$tf.2 ||
		error "(17) dd failed"
	sync

	cmp -bl $tf $tf.2 || error "(18) cmp failed"
	flush_and_compare $tf $tf.2 "(19)"

	# Now let's skip an entire chunk and do a full chunk at 640K
	dd if=$source bs=128K count=1 skip=5 seek=5 conv=notrunc of=$tf ||
		error "(20) dd failed"
	dd if=$source bs=128K count=1 skip=5 seek=5 conv=notrunc of=$tf.2 ||
		error "(21) dd failed"
	sync

	cmp -bl $tf $tf.2 || error "(22) cmp failed"
	flush_and_compare $tf $tf.2 "(23)"

	# Then one more partial, but compressible, chunk after that at
	# 768K
	dd if=$source bs=64K count=1 skip=12 seek=12 conv=notrunc of=$tf ||
		error "(24) dd failed"
	dd if=$source bs=64K count=1 skip=12 seek=12 conv=notrunc of=$tf.2 ||
		error "(25) dd failed"
	sync

	cmp -bl $tf $tf.2 || error "(26) cmp failed"
	flush_and_compare $tf $tf.2 "(27)"

	# OK, now we have this complex file, and we've tested reading it, let's
	# test reading it at a number of block sizes to give us unusual offsets
	echo "copying from compressed file with $bs"
	for bs in 3 4 7 32 97 128 130 192; do
		dd if=$tf bs=${bs}K of=$tf.3 ||
			error "(28) dd with block size ${bs}K failed"
		cmp -bl $tf.3 $tf.2 || error "(29) cmp failed"
		flush_and_compare $tf.3 $tf.2 "(30)"
		rm -f $tf.3
	done
}
run_test 1002 "test reads with incomplete chunks"

test_1003() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn126) )) ||
		skip "Need OST >= 2.14.0-ddn125-6-g033dd0ba2c for mmap compr"

	local tf=$DIR/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf
	# Larger than arm page size
	local chunksize=128

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		echo "bunzip2 is not installed, skip it"
		return 0
	fi

	# Fail test if source size changes so we catch this
	# Source should be a few MiB in size
	$CHECKSTAT -s 14625450 $source || error "checkstat wrong size"

	stack_trap "rm -f $tf $tf.*"

	local chunksizes=(
		64
		128
		1024
	)
	local blocksizes=(
		# Use a mix of chunk aligned and chunk unaligned sizes
		$((35 * 1024)) # 35K (etc)
		$((64 * 1024))
		$((100 * 1024))
		$((128 * 1024))
	)

	local seed=$(date +%s)
	echo "Random seed $seed."
	# Just test mmap reads, read-modify-write is not supported yet
	for chunksize in "${chunksizes[@]}"; do
	for blocksize in "${blocksizes[@]}"; do
		rm -f $tf*
		echo "Compression, using ${chunksize}K chunksize"
		$LFS setstripe -E -1 -Z lz4:0 --compress-chunk="$chunksize" "$tf" ||
			error "setstripe on $tf failed, chunsksize $chunksize"
		$LFS setstripe -E -1 -Z lz4:0 --compress-chunk="$chunksize" "$tf.2" ||
			error "setstripe on $tf.2 failed, chunsksize ${chunksize}K"

		mmap_copy_file -b $blocksize $source $tf ||
			error "mmap file copy failed (0)"

		flush_and_compare $source $tf "(1)"

		# Test partial overwrite by copying a random 50% of the file
		# This overwrites *parts* of the previously copied file
		mmap_copy_file -p 50 -b $blocksize $source $tf ||
			error "mmap file copy failed (2)"

		flush_and_compare $source $tf "(3)"

		# Copy from one compressed layout to another
		mmap_copy_file -b $blocksize $tf $tf.2 ||
			error "mmap file copy failed (4)"

		flush_and_compare $source $tf.2 "(5)"

		# Create a secondary copy of the source on a non-lustre fs
		cp $source $source.2

		# Partial overwrite with source compressed (tests reading)
		mmap_copy_file -p 50 -b $blocksize $tf $source.2 ||
			error "mmap file copy failed (6)"

		flush_and_compare $source $source.2 "(7)"

		rm -f $tf.2
		rm -f $tf.3

		$LFS setstripe -E -1 -Z lz4:0 --compress-chunk="$chunksize" "$tf.2" ||
			error "setstripe on $tf.2 failed, chunsksize ${chunksize}K"

		# Test again by copying random chunks totalling 50% of
		# file size (but copies are at random offsets)
		# We seed the random copy and copy from the original source,
		# then repeat the random copy from the compressed file with the
		# same seed and compare those two
		mmap_copy_file -s $seed -p 50 -b $blocksize $source $tf.2 ||
			error "mmap file copy failed (8)"
		mmap_copy_file -s $seed -p 50 -b $blocksize $tf $tf.3 ||
			error "mmap file copy failed (9)"

		flush_and_compare $tf.2 $tf.3 "(10)"
	done
	done
}
run_test 1003 "mmap test for compression"

test_1004() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn128) )) ||
		skip "Need OST >= 2.14.0-ddn127-8-g46708e4636 for partial compr"

	local tf=$DIR/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf
	local cpy_hdf=$TMP/$tfile.cpy.hdf
	local source=$cpy_hdf
	# Larger than arm page size
	local chunksize=128

	debugsave
	$LCTL set_param debug=-1 debug_mb=256

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		echo "bunzip2 is not installed, skip it"
		return 0
	fi

	# Use shifted hdf as source of data
	dd if=$tmp_hdf of=$cpy_hdf seek=7k ||
		error "failed creating an alternative data source"

	# Fail test if source size changes so we catch this
	# Source should be a few MiB in size
	$CHECKSTAT -s 14625450 $tmp_hdf || error "checkstat wrong size"

	stack_trap "rm -f $tf"

	# Simple compressed layout
	$LFS setstripe -E -1 -Z lz4:0 --compress-chunk=$chunksize $tf ||
		error "set a compress component in $tf failed"

	# Create file and verify - trivial
	dd if=$tmp_hdf bs=${chunksize}K of=$tf || error "(0) dd failed"
	flush_and_compare $tmp_hdf $tf "(1)"

	# Do a single 4K write - this will require a read-modify-write because
	# it is less than chunk size
	dd if=$source bs=4K of=$tf count=1 conv=notrunc || error "(2.1) dd failed"
	dd if=$source bs=4K of=$tmp_hdf count=1 conv=notrunc ||
		error "(2.2) dd failed"
	flush_and_compare $tmp_hdf $tf "(3)"

	# A single write of > chunk_size but < 2 chunks
	dd if=$source bs=$((chunksize * 3/2))K of=$tf count=1 conv=notrunc ||
		error "(4.1) dd failed"
	dd if=$source bs=$((chunksize * 3/2))K of=$tmp_hdf count=1 \
		conv=notrunc || error "(4.2) dd failed"
	flush_and_compare $tmp_hdf $tf "(5)"

	# Same test but offset slightly in to the file
	dd if=$source seek=1 skip=1 bs=$((chunksize * 3/2))K of=$tf count=1 conv=notrunc ||
		error "(6.1) dd failed"
	dd if=$source seek=1 skip=1 bs=$((chunksize * 3/2))K of=$tmp_hdf \
		count=1 conv=notrunc || error "(6.2) dd failed"
	flush_and_compare $tmp_hdf $tf "(7)"

	# Later tests use fsync to force read-modify-write
	# larger dd size with fsync (writing 4K at a time with fsync is slow)
	dd if=$source bs=$((chunksize / 2)) of=$tf conv=fsync,notrunc ||
		error "(8.1) dd failed"
	dd if=$source bs=$((chunksize / 2)) of=$tmp_hdf conv=fsync,notrunc ||
		error "(8.2) dd failed"
	flush_and_compare $tmp_hdf $tf "(9)"

	# Larger than chunk size
	dd if=$source bs=$((chunksize * 3/2)) of=$tf conv=fsync,notrunc ||
		error "(10.1) dd failed"
	dd if=$source bs=$((chunksize * 3/2)) of=$tmp_hdf conv=fsync,notrunc ||
		error "(10.2) dd failed"
	flush_and_compare $tmp_hdf $tf "(11)"

	# The above test is full pages on x86, sometimes partial on ARM
	# This will explicitly test readup of partial chunks as part of a write
	# This writes one full page, then part of the next page
	# This forces a partial page read before we can do the write
	dd if=$source bs=$((PAGE_SIZE * 2 - 1024)) of=$tf conv=notrunc ||
		error "(12.1) dd failed"
	dd if=$source bs=$((PAGE_SIZE * 2 - 1024)) of=$tmp_hdf conv=notrunc ||
		error "(12.2) dd failed"
	flush_and_compare $tmp_hdf $tf "(13)"

	# Do the same test at an offset in the file
	dd if=$source seek=4 skip=4 bs=$((PAGE_SIZE * 2 - 1024)) of=$tf conv=notrunc ||
		error "(14.1) dd failed"
	dd if=$source seek=4 skip=4 bs=$((PAGE_SIZE * 2 - 1024)) of=$tmp_hdf conv=notrunc ||
		error "(14.2) dd failed"
	flush_and_compare $tmp_hdf $tf "(15)"
	debugrestore
}
run_test 1004 "initial test for write updating"

test_1005() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn128) )) ||
		skip "Need OST >= 2.14.0-ddn127-8-g46708e4636 for partial compr"

	local tf=$DIR/$tfile
	local tf_copy=$TMP/$tfile.copy
	# We read from $tfile to this
	# Larger than arm page size
	local chunksize=128
	local read_ahead_mb
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		echo "bunzip2 is not installed, skip it"
		return 0
	fi

	# Fail test if source size changes so we catch this
	# Source should be a few MiB in size
	$CHECKSTAT -s 14625450 $source || error "checkstat wrong size"

	stack_trap "rm -f $tf"

	# Disable readahead so reads are not expanded to full chinks
	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	$LCTL set_param llite.*.max_read_ahead_mb=0
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb" EXIT

	# Simple compressed layout
	$LFS setstripe -E -1 -Z lz4:0 --compress-chunk=$chunksize $tf ||
		error "set a compress component in $tf failed"

	# These tests will deliberately create unusual files, using the sample
	# hdf5 file as a reference, but cannot compare to it because they
	# copy only part of it.  So all of them will also create an identical
	# uncompressed file to compare against.
	# Create the simplest possible example of a file with an incomplete
	# chunk, just 4K at the beginning (this won't be compressed, but it's
	# still a valid test)
	dd if=$source bs=4K of=$tf count=1 || error "(0) dd failed"
	dd if=$source bs=4K of=$tf_copy count=1 || error "(1) dd failed"

	flush_and_compare $tf $tf_copy "(2)"

	# Now we write adjacent in this first chunk, confirming updating it works
	# Write 4K twice starting at an offset of 4K
	dd if=$source bs=4K of=$tf conv=notrunc count=2 seek=1 skip=1 || error "(3) dd failed"
	dd if=$source bs=4K of=$tf_copy conv=notrunc count=2 seek=1 skip=1 || error "(4) dd failed"

	flush_and_compare $tf $tf_copy "(5)"

	# Now we jump a bit further on and do a write
	# Write 8K at an offset of 32K
	dd if=$source bs=8K of=$tf conv=notrunc count=1 seek=4 skip=4 || error "(6) dd failed"
	dd if=$source bs=8K of=$tf_copy conv=notrunc count=1 seek=4 skip=4 || error "(7) dd failed"

	flush_and_compare $tf $tf_copy "(8)"

	# None of the above was compressed, because the first write was too
	# small and the later writes weren't chunk aligned.  Confirm the server
	# didn't do any decompression/compression
	#FIXME: Stats check goes here once available

	# OK, now we truncate the file back to zero and start with a compressed
	# chunk at the beginning.
	# Write 16K at 0 - this will be compressed
	dd if=$source bs=16K of=$tf count=1 || error "(9) dd failed"
	dd if=$source bs=16K of=$tf_copy count=1 || error "(10) dd failed"

	flush_and_compare $tf $tf_copy "(11)"

	# Now we do the same size of write slightly further down
	# 16K in to existing chunk - read-modify-write
	# Seek to 32K and write 16K
	dd if=$source bs=16K of=$tf count=1 seek=2 skip=2 conv=notrunc || error "(12) dd failed"
	dd if=$source bs=16K of=$tf_copy count=1 seek=2 skip=2 conv=notrunc || error "(13) dd failed"

	flush_and_compare $tf $tf_copy "(14)"

	# OK, now we're going to create a complete compressed chunk further
	# along in the file
	# Seek to 128K and write 128K
	dd if=$source bs=128K count=1 skip=1 seek=1 conv=notrunc of=$tf ||
		error "(15) dd failed"
	dd if=$source bs=128K count=1 skip=1 seek=1 conv=notrunc of=$tf_copy ||
		error "(16) dd failed"

	flush_and_compare $tf $tf_copy "(17)"

	# Now we're going to write *into* the middle of this compressed chunk
	# Seek to 160K and write 32K
	dd if=$source bs=32K count=1 skip=5 seek=5 conv=notrunc of=$tf ||
		error "(18) dd failed"
	dd if=$source bs=32K count=1 skip=5 seek=5 conv=notrunc of=$tf_copy ||
		error "(19) dd failed"

	flush_and_compare $tf $tf_copy "(20)"

	# OK, now we're going to add another incomplete chunk after those
	# two - starting in the third chunk, ie, offset of 256K
	# This will be compressed
	# Seek to 256K and write 64K
	dd if=$source bs=64K count=1 skip=4 seek=4 conv=notrunc of=$tf ||
		error "(21) dd failed"
	dd if=$source bs=64K count=1 skip=4 seek=4 conv=notrunc of=$tf_copy ||
		error "(22) dd failed"

	flush_and_compare $tf $tf_copy "(23)"

	# Now we're going to write the second 'half' of this chunk
	# Seek to 320K and write 64K
	dd if=$source bs=64K count=1 skip=5 seek=5 conv=notrunc of=$tf ||
		error "(24) dd failed"
	dd if=$source bs=64K count=1 skip=5 seek=5 conv=notrunc of=$tf_copy ||
		error "(25) dd failed"

	flush_and_compare $tf $tf_copy "(26)"

	# And now we're going to add a chunk that doesn't start at offset 0,
	# so it won't be compressed.  This is the fourth chunk, so starts at
	# 384K.  So we'll start at 448K
	# Seek to 448K and write 64K
	dd if=$source bs=64K count=1 skip=7 seek=7 conv=notrunc of=$tf ||
		error "(27) dd failed"
	dd if=$source bs=64K count=1 skip=7 seek=7 conv=notrunc of=$tf_copy ||
		error "(28) dd failed"

	flush_and_compare $tf $tf_copy "(29)"

	# Now we'll write a few KiB in to the middle of the first part of this
	# chunk - starting at 400K
	# Seek to 400K and write 8K
	dd if=$source bs=8K count=2 skip=50 seek=50 conv=notrunc of=$tf ||
		error "(30) dd failed"
	dd if=$source bs=8K count=2 skip=50 seek=50 conv=notrunc of=$tf_copy ||
		error "(31) dd failed"

	flush_and_compare $tf $tf_copy "(32)"

	# Now let's skip an entire chunk and do a full chunk at 640K
	# Seek 640K and write 128K
	dd if=$source bs=128K count=1 skip=5 seek=5 conv=notrunc of=$tf ||
		error "(33) dd failed"
	dd if=$source bs=128K count=1 skip=5 seek=5 conv=notrunc of=$tf_copy ||
		error "(34) dd failed"

	flush_and_compare $tf $tf_copy "(35)"

	# Then one more partial, but compressible, chunk after that at
	# 768K
	# Seek to 768K and write 64K
	dd if=$source bs=64K count=1 skip=12 seek=12 conv=notrunc of=$tf ||
		error "(36) dd failed"
	dd if=$source bs=64K count=1 skip=12 seek=12 conv=notrunc of=$tf_copy ||
		error "(37) dd failed"

	flush_and_compare $tf $tf_copy "(38)"

	# OK, now we have this complex file, let's test reading it at a
	# number of block sizes to give us unusual offsets
	echo "copying from compressed file with $bs"
	for bs in 3 4 7 32 97 128 130 192; do
		dd if=$tf bs=${bs}K of=$tf.3 ||
			error "(39) dd with block size ${bs}K failed"

		flush_and_compare $tf $tf.3 "(40)"
		rm -f $tf.3
	done
}
run_test 1005 "test for write updating with partial chunks"

test_1006() {
	(( $OST1_VERSION >= $(version_code 2.14.0.128) )) ||
		skip "Need OST >= 2.14.0-ddn127-9-g6c4c4d7599 for partial compr"

	local tf=$DIR/$tfile
	local tf2=$DIR2/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf
	# Larger than arm page size
	local chunksize=128
	local cs_bytes=$((chunksize * 1024))

	# Larger than arm page size
	local chunksize=128

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		echo "bunzip2 is not installed, skip it"
		return 0
	fi

	mount_client $MOUNT2
	stack_trap "umount_client $MOUNT2" EXIT

	# Fail test if source size changes so we catch this
	# Source should be a few MiB in size
	$CHECKSTAT -s 14625450 $source || error "checkstat wrong size"

	stack_trap "rm -f $tf $tf.source $tf2"

	$LFS setstripe -E -1 -Z lz4:0 --compress-chunk=$chunksize $tf.source ||
		error "set a compress component in $tf.source failed"

	# Copy the source file to Lustre so we also read from Lustre
	dd if=$source of=$tf.source bs=1M || error "dd to create $tf.source failed"
	flush_and_compare $source $tf.source "(0) failed compare of source"

	for bs in $((PAGE_SIZE - 1024)) $PAGE_SIZE $((PAGE_SIZE * 3/2)) \
		$(((cs_bytes - 1024))) $cs_bytes $((cs_bytes * 3/2)); do

		# Simple compressed layout
		$LFS setstripe -E -1 -Z lz4:0 --compress-chunk=$chunksize $tf ||
			error "set a compress component in $tf failed"

		echo "bs: $bs"
		dd if=$tf.source bs=$bs of=$tf conv=notrunc &
		pid1=$!
		# Second mount with similar but not the same block size
		dd if=$tf.source bs=$((bs * 2)) of=$tf2 conv=notrunc &
		pid2=$!
		wait $pid1
		rc1=$?
		wait $pid2
		rc2=$?
		if (( rc1 != 0 )); then
			error "copy 1 w/bsize $bs failed: $rc1"
		fi
		if (( rc2 != 0 )); then
			error "copy 2 w/bsize $bs failed: $rc2"
		fi

		flush_and_compare $source $tf "(1) failed compare with size $bs"
		flush_and_compare $tf $tf2 "(2) failed compare with size $bs"
		rm -f $tf $tf2
	done
}
run_test 1006 "racing writes with compressed layout"

test_1007() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn128) )) ||
		skip "Need OST >= 2.14.0-ddn127-9-g6c4c4d7599 for good compr"

	# The ll_compression_scan tool requires the lz4 lzop zstd and gzip
	# utilities to be installed in order to test those compression types.
	# (lzop is the command line utility for lzo compression)
	local -a compr_types
	local utility
	local rc

	for utility in ll_compression_scan lz4 lzop zstd gzip; do
		which $utility &>/dev/null
		rc=$?

		case $utility-$rc in
		lz4-0) compr_types+=(lz4 lz4fast) ;;
		lzop-0) compr_types+=(lzo) ;;
		zstd-0) compr_types+=(zstd zstdfast) ;;
		gzip-0) compr_types+=(gzip) ;;
		ll_compression_scan-1) error "'$utility' is not installed";;
		*-1) echo "'$utility' not found"; continue;;
		esac
	done

	[[ -n "${compr_types}" ]] || skip_env "no compression tools installed"
	echo "compr_types: $compr_types"

	local tf=$DIR/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		skip_env "bunzip2 is not installed"
	fi

	local compr_levels=(
		1
		6
		9
	)

	local chunksizes=(
		64
		128
		1024
	)

	local compr_type
	local compr_level
	local chunksize
	# lzo does not grok a compression level, add here other such algs
	local type_nolvl="lzo"
	local total_estimates=0
	local failed_estimates=0
	local failed_margin=50

	# Fail test if source size changes so we catch this
	# Source should be a few MiB in size
	$CHECKSTAT -s 14625450 $source || error "checkstat wrong size"

	stack_trap "rm -f $tf"

	for compr_type in ${compr_types[@]}; do
	for compr_level in ${compr_levels[@]}; do
	for chunksize in "${chunksizes[@]}"; do
		rm -f $tf
		local has_level=""
		[[ "$type_nolvl" =~ "$compr_type" ]] || has_level="yes"

		local compr_info="algorithm $compr_type"
		[[ -z $has_level ]] || compr_info+=", level $compr_level"
		compr_info+=", and chunsksize ${chunksize}K"

		$LCTL set_param -n osc.*.stats_compr=0

		echo "Compression, using $compr_info"
		$LFS setstripe -E -1 \
			-Z ${compr_type}${has_level:+":${compr_level}"} \
			--compress-chunk=$chunksize $tf ||
			error "setstripe on $tf failed with $compr_info"

		cp -a $source $tf || error "copy $source to $tf failed"
		# Sync to disk and drop cache
		sync; echo 3 > /proc/sys/vm/drop_caches

		local scan_cmd="ll_compression_scan -m 0 -w -q -z $compr_type"
		[[ -z $has_level ]] || scan_cmd+=" -l $compr_level"
		scan_cmd+=" -c $chunksize"

		local estimated_size=$($scan_cmd $source |
			awk '/Estimated compressed size/ { print $7 }')
		[[ -n "$estimated_size" ]] || error "no compression estimate"
		estimated_size=$(bc -l <<< "$estimated_size * 1024")
		local csdc_size=$(du -sk $tf | awk '{print $1}')

		local margin=5
		local real_margin=0
		echo "Estimated compressed size: $estimated_size KiB"
		echo "CSDC size: $csdc_size KiB"
		real_margin=$(( csdc_size * 100 / ${estimated_size%%.*} ))
		(( real_margin > 100 )) && (( real_margin -= 100 )) ||
			real_margin=$(( 100 - real_margin ))
		(( real_margin <= margin )) ||
		{
			local error_msg="estimated compressed size: "
			error_msg+="$estimated_size KiB, "
			error_msg+="got: $csdc_size KiB, "
			error_msg+="margin ${real_margin}% exceeded ${margin}%"
			error_ignore_no_dump EX-7795 "$error_msg"

			$LCTL get_param -n osc.*.stats_compr |
				grep -v 'compr: 0'

			(( failed_estimates += 1 ))
		}

		(( total_estimates += 1 ))
	done # chunksize
	[[ -n $has_level ]] || break
	done # compr_level
	done # compr_type

	(( failed_estimates <= total_estimates * failed_margin / 100 )) ||
		error "failed estimates > ${failed_margin}% of total estimates"
}
run_test 1007 "validate file space usage reduction with compression"

test_1008() {
	local before
	local after

	(( $OST1_VERSION >= $(version_code 2.14.0-ddn128) )) ||
		skip "Need OST >= 2.14.0-ddn127-9-g6c4c4d7599 for good compr"

	# The ll_compression_scan tool requires the lz4 lzop zstd and gzip
	# utilities to be installed in order to test those compression types.
	# (lzop is the command line utility for lzo compression)
	local -a compr_types
	local utility
	local rc

	for utility in ll_compression_scan lz4 lzop zstd gzip; do
		which $utility &>/dev/null
		rc=$?

		case $utility-$rc in
		lz4-0) compr_types+=(lz4 lz4fast) ;;
		lzop-0) compr_types+=(lzo) ;;
		zstd-0) compr_types+=(zstd zstdfast) ;;
		gzip-0) compr_types+=(gzip) ;;
		ll_compression_scan-1) error "'$utility' is not installed";;
		*-1) echo "'$utility' not found"; continue;;
		esac
	done

	[[ -n "${compr_types}" ]] || skip_env "no compression tools installed"

	local compr_levels=(
		1
		6
		9
	)

	local chunksizes=(
		64
		128
		1024
	)

	local compr_type
	local compr_level
	local chunksize
	# lzo does not grok a compression level, add here other such algs
	local type_nolvl="lzo"
	local total_estimates=0
	local failed_estimates=0
	local failed_margin=50

	local td=$DIR/$tdir
	local source=$TMP/$tdir
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$source/$tfile.hdf

	mkdir -p $source || error "mkdir -p $source failed"

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		skip_env "bunzip2 is not installed"
	fi

	cp -a $tmp_hdf{,.bak} || error "copy $tmp_hdf failed"
	cp -a /etc $source || error "copy /etc failed"
	# Sync to disk and drop cache
	sync; echo 3 > /proc/sys/vm/drop_caches

	stack_trap "rm -rf $td $TMP/$tdir"

	for compr_type in ${compr_types[@]}; do
	for compr_level in ${compr_levels[@]}; do
	for chunksize in "${chunksizes[@]}"; do
		rm -rf $td
		mkdir $td || error "mkdir $td failed"

		local has_level=""
		[[ "$type_nolvl" =~ "$compr_type" ]] || has_level="yes"

		local compr_info="algorithm $compr_type"
		[[ -z $has_level ]] || compr_info+=", level $compr_level"
		compr_info+=", and chunsksize ${chunksize}K"

		$LCTL set_param -n osc.*.stats_compr=0

		echo "Compression, using $compr_info"
		$LFS setstripe -E -1 \
			-Z ${compr_type}${has_level:+":${compr_level}"} \
			--compress-chunk=$chunksize $td ||
			error "setstripe on $td failed with $compr_info"

		before=$SECONDS
		cp -a $source $td || error "copy $source to $td failed"
		# Sync to disk and drop cache
		sync; echo 3 > /proc/sys/vm/drop_caches
		after=$SECONDS
		echo "Took $((after - before)) secs to copy files (incl. sync)."

		local scan_cmd="ll_compression_scan -m 0 -w -q -z $compr_type"
		[[ -z $has_level ]] || scan_cmd+=" -l $compr_level"
		scan_cmd+=" -c $chunksize"

		before=$SECONDS
		local estimated_size=$($scan_cmd $source |
			awk '/Estimated compressed size/ { print $7 }')
		[[ -n "$estimated_size" ]] || error "no compression estimate"
		after=$SECONDS
		echo "Took $((after - before)) secs to estimate compressed size."
		estimated_size=$(bc -l <<< "$estimated_size * 1024")
		local csdc_size=$(du -skc $(find $td -type f) | awk '/total$/{print $1}')

		local margin=5
		local real_margin=0

		# CentOS 7.9 consistently has worse compression ratios
		# We shouldn't disable this testing completely, but it
		# also isn't very interesting to fix this old client.
		[[ $CLIENT_OS_ID_LIKE =~ rhel ]] &&
			(( $CLIENT_OS_VERSION_CODE <= $(version_code 7.9) )) &&
			margin=15

		echo "Estimated compressed size: $estimated_size KiB"
		echo "CSDC size: $csdc_size KiB"
		real_margin=$(( csdc_size * 100 / ${estimated_size%%.*} ))
		(( real_margin > 100 )) && (( real_margin -= 100 )) ||
			real_margin=$(( 100 - real_margin ))
		(( real_margin <= margin )) ||
		{
			local error_msg="estimated compressed size: "
			error_msg+="$estimated_size KiB, "
			error_msg+="got: $csdc_size KiB, "
			error_msg+="margin ${real_margin}% exceeded ${margin}%"
			error_ignore_no_dump EX-7795 "$error_msg"

			$LCTL get_param -n osc.*.stats_compr |
				grep -v 'compr: 0'

			(( failed_estimates += 1 ))
		}

		(( total_estimates += 1 ))
	done # chunksize
	[[ -n $has_level ]] || break
	done # compr_level
	done # compr_type

	if (( failed_estimates > total_estimates * failed_margin / 100 )); then
		local arch=$(uname -m)
		# these should be fixed, but ignore so other patches can land.
		# better to continue running tests on these systems than skip.
		error "failed > ${failed_margin}% of total estimates" \
			" ($failed_estimates / $total_estimates)"
	fi
}
run_test 1008 "validate directory space usage reduction with compression"

# args:
#  - where to get new data (zero, urandom)
#  - target file (compressed)
#  - check file (uncompressed), doubles all data for verification
#  - number of bytes to write
#  - offset in bytes
compr_write_test() {
	local tf="$2"
	local chf="$3"
	local sz=$4
	local off=$5

	local tmpf=$(mktemp)
	stack_trap "rm -f tmpf"

	local src="/dev/$1"
	[[ $1 == /* ]] && echo "USE FILE $1" && src=$1
	[[ -f $src || -c $src ]] || error "no source $src"

	[[ -n $sz ]] || error "no size specifiedf"
	(( $sz > 0 && $sz < 4*1024*1024 )) || error "invalid size $sz"
	[[ -n $off ]] || error "no offset specifiedf"
	[[ -f $tf ]] || error "no target $tf"
	[[ -f $chf ]] || error "no check file $chf"

	# generate data
	dd if=$src of=$tmpf bs=1 count=$sz >/dev/null ||
		error "can't get data from $src"

	# save to the checkfile, to compare with the target later
	dd if=$tmpf of=$chf bs=1 count=$sz seek=$off conv=notrunc >/dev/null ||
		error "can't write to the checkfile $chf"

	# now to the target file
	cancel_lru_locks osc
	echo
	echo "WRITE $sz at $off:"
	dd if=$tmpf of=$tf bs=1 count=$sz seek=$off conv=notrunc >/dev/null ||
		error "can't write to the target file"

	[[ -n $6 && -n $7 ]] && {
		sz=$6
		off=$7
		# generate data
		dd if=$src of=$tmpf bs=1 count=$sz >/dev/null ||
			error "can't get data from $src"
		# save to the checkfile, to compare with the target later
		dd if=$tmpf of=$chf bs=1 count=$sz seek=$off conv=notrunc >/dev/null ||
			error "can't write to the checkfile $chf"
		echo "WRITE $sz at $off:"
		dd if=$tmpf of=$tf bs=1 count=$sz seek=$off conv=notrunc,fdatasync >/dev/null ||
			error "can't write to the target file"

	}
	cancel_lru_locks osc

	[[ -n $DONT_CHECK_DATA ]] && return 0

	cmp $chf $tf || {
		echo "WRITE $sz at $off FAILED (or subsequent read :)"
		echo -n "CHECK  FILE: "
		ls -l $chf
		hexdump -C $chf | head -5
		echo -n "TARGET FILE: "
		ls -l $tf
		hexdump -C $tf | head -5
		cancel_lru_locks osc
		cmp -bl $chf $tf | head -32
		error "checkfile and target file don't match"
	}

	rm -f $tmpf
}

compr_read_test() {
	local tf="$1"
	local chf="$2"
	local bs=$3
	local count=$4
	local skip=$5

	[[ -n $bs ]] || error "no size specifiedf"
	[[ -n $count ]] || error "no size specifiedf"
	[[ -n $skip ]] || error "no offset specifiedf"
	[[ -f $tf ]] || error "no target $tf"
	[[ -f $chf ]] || error "no check file $chf"

	local tmpf=$(mktemp)
	local tmpf2=$(mktemp)

	dd if=$checkf of=$tmpf bs=$bs count=$count skip=$skip >&/dev/null ||
		error "can't read $checkf"
	cancel_lru_locks osc
	dd if=$tf of=$tmpf2 bs=$bs count=$count skip=$skip >&/dev/null ||
		error "can't read $tf"
	cmp $tmpf $tmpf2 || {
		ls -l $checkf
		ls -l $tf
		ls -l $tmpf
		ls -l $tmpf2
		hexdump -C -s 470753 -n 32 $tmpf
		hexdump -C -s 470753 -n 32 $tmpf2
		cancel_lru_locks osc
		cmp $checkf $tf && echo "BUT FULL READ MATCH"
		error "reads don't match"
	}

	rm -f $tmpf $tmpf2
}

compr_truncate_test() {
	local tf="$1"
	local chf="$2"
	local sz=$3

	[[ -f $tf ]] || error "no target $tf"
	[[ -f $chf ]] || error "no check file $chf"
	[[ -n $sz ]] || error "define size"

	$TRUNCATE $chf $sz || error "can't truncate $chf"
	$TRUNCATE $tf $sz || error "can't truncate $tf"

	cancel_lru_locks osc
	cmp $chf $tf ||
		error "checkfile and taret file don't match after truncate"
}

test_chunk_rw() {
	local orig="$1"
	local checkf="$2"
	local tf="$3"
	local chsz=$4

	$TRUNCATE $checkf 0
	rm -f $tf
	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4:0 --compress-chunk=$chsz $tf ||
		error "can't setstripe"
	$LFS getstripe $tf | grep compress || error "no compression used?"

	# full chunk write
	compr_write_test zero $tf $checkf $((chsz*1024)) 0

	# full chunk overwrite with same data (i.e. same compression)
	compr_write_test zero $tf $checkf $((chsz*1024)) 0 0

	# full chunk overwrite with compressible data (no idea about result)
	compr_write_test $orig $tf $checkf $((chsz*1024)) 0

	# partial chunk overwrite (start of the chunk)
	compr_write_test $orig $tf $checkf $((chsz*1024/2)) 0

	# partial chunk overwrite (start of the chunk, page aligned)
	compr_write_test $orig $tf $checkf $((chsz*1024)) 0
	compr_write_test $orig $tf $checkf $((chsz*1024/4)) 4096

	# partial chunk overwrite (inside the chunk, page unaligned)
	compr_write_test $orig $tf $checkf $((chsz*1024)) 0
	compr_write_test $orig $tf $checkf $((chsz*1024/4)) 8192

	# partial chunk overwrite (inside the chunk, page unaligned)
	compr_write_test $orig $tf $checkf $((chsz*1024)) 0
	compr_write_test $orig $tf $checkf $((chsz*1024/2)) 5000

	# partial chunk overwrite (end of the chunk, page aligned)
	compr_write_test $orig $tf $checkf $((chsz*1024)) 0
	compr_write_test $orig $tf $checkf $((chsz*1024/4)) $((chsz*1024*3/4))

	# partial chunk overwrite + full chunk write
	compr_write_test $orig $tf $checkf $((chsz*1024)) 0
	compr_write_test zero $tf $checkf $((chsz*1024*3/2)) $((chsz*1024/2))

	# 2 full chunk overwrite
	compr_write_test zero $tf $checkf $((chsz*1024)) 0
	compr_write_test zero $tf $checkf $((chsz*1024*3/2)) $((chsz*1024/2))

	# full compressed tail write
	compr_write_test $orig $tf $checkf 8000 $((chsz*5*1024))

	# full compressed tail overwrite
	compr_write_test $orig $tf $checkf 20000 $((chsz*5*1024))

	# partial tail overwrite (start of the tail chunk)
	compr_write_test $orig $tf $checkf 3003 $((chsz*5*1024))

	# partial tail overwrite (middle of the tail chunk)
	compr_write_test $orig $tf $checkf 3000 $((chsz*5*1024 + 1024))

	# partial tail extending overwrite (filesize was chunk*5 + 20000
	compr_write_test $orig $tf $checkf 10000 $((chsz*5*1024 + 20000 - 5000))

	# full compressed tail overwrite extending size
	compr_write_test $orig $tf $checkf 10000 $((chsz*7*1024))
	compr_write_test $orig $tf $checkf 12000 $((chsz*7*1024))

	# partial tail (which is compressed) non-chunk-aligned overwrite extending size
	compr_write_test $orig $tf $checkf 10000 $((chsz*8*1024))
	compr_write_test $orig $tf $checkf 12000 $((chsz*8*1024 + 512))

	# the last byte of compressed chunk (
	compr_write_test $orig $tf $checkf $((chsz*1024)) $((chsz*9*1024))
	compr_write_test $orig $tf $checkf 1 $((chsz*9*1024+chsz*1024-1))

	# partial tail overwrite extending file size
	compr_write_test zero $tf $checkf $((chsz*1024/2)) $((chsz*10*1024))
	compr_write_test zero $tf $checkf $((chsz*1024/2)) $((chsz*10*1024+8192))

	# full uncompressed chunk overwrite with compressible data
	compr_write_test urandom $tf $checkf $((chsz*1024)) $((chsz*11*1024))
	compr_write_test zero $tf $checkf $((chsz*1024)) $((chsz*11*1024))

	# overwrite compressed chunk at different offsets with subchunk sizes
	compr_write_test zero $tf $checkf $((chsz*1024)) $((chsz*12*1024))
	compr_write_test urandom $tf $checkf 4096 $((chsz*12*1024))
	compr_write_test urandom $tf $checkf 8192 $((chsz*12*1024+8192))
	compr_write_test urandom $tf $checkf 512 $((chsz*12*1024+8192))
	compr_write_test urandom $tf $checkf 1024 $((chsz*13*1024-1024))

	# two niobufs per chunk
	compr_write_test zero $tf $checkf 4096 $((chsz*13*1024+4096)) \
		4096 $((chsz*13*1024+4*4096))
	compr_write_test zero $tf $checkf $((chsz*1024)) $((chsz*13*1024))
	compr_write_test urandom $tf $checkf 4096 $((chsz*13*1024+4096)) \
		4096 $((chsz*13*1024+4*4096))
	compr_write_test urandom $tf $checkf 8192 $((chsz*13*1024)) \
		8192 $((chsz*13*1024+5*4096))
}

test_1009a() {
	local orig=$(mktemp)
	local tf=$DIR/$tfile
	local checkf=$(mktemp)
	local chsz
	local read_ahead_mb
	local readcache
	local writecache

	stack_trap "rm -f $tf $orig $checkf"

	# XXX check /etc/services has enough data
	cat /etc/services /etc/services /etc/services >$orig

	# Disable compressibility check which can break test's expectation
	local saved_check_bytes=$($LCTL get_param -n osc.*OST0000*.compress_check_bytes)
	stack_trap "$LCTL set_param osc.*.compress_check_bytes=$saved_check_bytes"
	$LCTL set_param osc.*.compress_check_bytes=32M

	# Disable readahead so reads are not expanded to full chunks
	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb"
	$LCTL set_param llite.*.max_read_ahead_mb=0

	readcache=$(do_facet ost1 $LCTL get_param -n osd*.*OST0000.read_cache_enable)
	writecache=$(do_facet ost1 $LCTL get_param -n osd*.*OST0000.writethrough_cache_enable)
	stack_trap "do_facet ost1 $LCTL set_param osd*.*OST0000.writethrough_cache_enable=$writecache"
	stack_trap "do_facet ost1 $LCTL set_param osd*.*OST0000.read_cache_enable=$readcache"

	for cache in 0 1; do
		do_facet ost1 $LCTL set_param osd*.*OST0000*.writethrough_cache_enable=$cache
		do_facet ost1 $LCTL set_param osd*.*OST0000*.read_cache_enable=$cache
		do_facet ost1 $LCTL get_param osd*.*OST0000.stats|grep cache

		for chsz in 64 128; do
			test_chunk_rw $orig $checkf $tf $chsz
		done

		do_facet ost1 $LCTL get_param osd*.*OST0000.stats|grep cache
	done
}
run_test 1009a "compression: basic tests"

test_1009b() {
	local orig=$(mktemp)
	local tf=$DIR/$tfile
	local checkf=$(mktemp)
	local read_ahead_mb

	stack_trap "rm -f $tf $orig $checkf"

	# XXX check /etc/services has enough data
	cat /etc/services /etc/services /etc/services >$orig
	ls -l $orig

	# Disable compressibility check which can break test's expectation
	local saved_check_bytes=$($LCTL get_param -n osc.*OST0000*.compress_check_bytes)
	stack_trap "$LCTL set_param osc.*.compress_check_bytes=$saved_check_bytes"
	$LCTL set_param osc.*.compress_check_bytes=32M

	# Disable readahead so reads are not expanded to full chinks
	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb"
	$LCTL set_param llite.*.max_read_ahead_mb=0

	readcache=$(do_facet ost1 $LCTL get_param -n osd*.*OST0000.read_cache_enable)
	writecache=$(do_facet ost1 $LCTL get_param -n osd*.*OST0000.writethrough_cache_enable)
	stack_trap "do_facet ost1 $LCTL set_param osd*.*OST0000.writethrough_cache_enable=$writecache"
	stack_trap "do_facet ost1 $LCTL set_param osd*.*OST0000.read_cache_enable=$readcache"

	for cache in 0 1; do
		do_facet ost1 $LCTL set_param osd*.*OST0000*.writethrough_cache_enable=$cache
		do_facet ost1 $LCTL set_param osd*.*OST0000*.read_cache_enable=$cache
		do_facet ost1 $LCTL get_param osd*.*OST0000.stats|grep cache

		for chsz in 64 128; do
			$TRUNCATE $checkf 0
			rm -f $tf
			$LFS setstripe -i 0 -c 1 -E -1 -Z lz4 --compress-chunk=$chsz $tf ||
				error "can't setstripe"
			$LFS getstripe $tf | grep compress || error "no compression used?"

			compr_write_test $orig $tf $checkf $((chsz*7*1024)) 0

			# truncate compressed file to chunk-aligned size
			compr_truncate_test $tf $checkf $((chsz*6*1024))
			compr_truncate_test $tf $checkf $((chsz*5*1024))

			# truncate compressed file to non-chunk-aligned size
			compr_truncate_test $tf $checkf $((chsz*4*1024+4000))
			compr_truncate_test $tf $checkf $((chsz*3*1024+8192))
			compr_truncate_test $tf $checkf $((chsz*2*1024+8001))
			compr_truncate_test $tf $checkf $((chsz*1*1024+8192))

			# truncate far ahead
			compr_truncate_test $tf $checkf $((chsz*1024*1+1000))
			compr_truncate_test $tf $checkf $((chsz*1024*300))
			compr_truncate_test $tf $checkf $((chsz*1024*300+100))

			compr_truncate_test $tf $checkf 0
			compr_truncate_test $tf $checkf 1000

			# EX-10391
			(( $OST1_VERSION >= $(version_code 2.14.0-ddn169) )) ||
				continue
			local trs=40565
			dd if=$orig of=$checkf bs=$trs count=1 ||
				error "can't prepare $checkf"
			dd if=/dev/zero of=$checkf bs=1 count=$((1024*1024-trs)) \
				seek=$trs conv=notrunc || error "can't prepare $checkf"
			dd if=$checkf of=$tf bs=1M count=1 conv=fsync || error "can't dd"
			compr_truncate_test $tf $checkf $trs
		done
	done
}
run_test 1009b "compression: truncate"

#run_test 1009c "compression: performance"

test_1009d() {
	local tf=$DIR/$tfile
	local checkf=$(mktemp)
	local chsz=64
	local orig="/etc/services"
	local read_ahead_mb

	stack_trap "rm -f $tf $checkf"

	# XXX check /etc/services has enough data

	# Disable compressibility check which can break test's expectation
	local saved_check_bytes=$($LCTL get_param -n osc.*OST0000*.compress_check_bytes)
	stack_trap "$LCTL set_param osc.*.compress_check_bytes=$saved_check_bytes"
	$LCTL set_param osc.*.compress_check_bytes=32M

	# Disable readahead so reads are not expanded to full chunks
	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb"
	$LCTL set_param llite.*.max_read_ahead_mb=0

	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4 --compress-chunk=$chsz $tf ||
		error "can't setstripe"
	$LFS getstripe $tf | grep compress || error "no compression used?"

	compr_write_test $orig $tf $checkf $((chsz*1024*3)) 0

#define OBD_FAIL_OST_BRW_WRITE_BULK3     0x256
	do_facet ost1 "$LCTL set_param fail_loc=0x80000256"

	# partial chunk overwrite (start of the chunk)
	DONT_CHECK_DATA=y compr_write_test $orig $tf $checkf $((chsz*1024/2)) 0

	do_facet ost1 "$LCTL set_param fail_loc=0x0"
	# partial chunk overwrite (start of the chunk)
	compr_write_test $orig $tf $checkf $((chsz*1024/2)) 0
}
run_test 1009d "compression: bulk error"

1009e_check() {
	local src="$1"
	local seek=$2
	local count=$3
	local blocks

	do_facet ost1 $LCTL set_param -n osd-ldiskfs.lustre-OST0000.brw_stats=clear
	dd if=/dev/$src of=$tf bs=4k seek=$seek count=$count \
		conv=notrunc,fdatasync >&/dev/null ||
			error "can't dd"

	# calculate how many 4K blocks have been written
	blocks=0
	while read sz r1 r2 r3 sep w1 w2 w3; do
		[[ $sz == *K: ]] || continue
		sz=${sz%K:}
		(( blocks = blocks + sz/4*w1 ))
	done < <(do_facet ost1 $LCTL get_param -n osd-ldiskfs.lustre-OST0000.brw_stats |
		awk '/disk I.O size/{f=1;nextline}{if(f==1){print}}/^$/{if(f==1){nextfile}}')

	echo $blocks
}

test_1009e() {
	local tf=$DIR/$tfile
	local checkf=$(mktemp)
	local chsz=128
	local orig="/etc/services"
        local pgsz=$(getconf PAGESIZE)
	local b

	stack_trap "rm -f $tf $checkf"

	# XXX check /etc/services has enough data

	# Disable compressibility check which can break test's expectation
	local saved_check_bytes=$($LCTL get_param -n osc.*OST0000*.compress_check_bytes)
	stack_trap "$LCTL set_param osc.*.compress_check_bytes=$saved_check_bytes"
	$LCTL set_param osc.*.compress_check_bytes=32M

	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4 --compress-chunk=$chsz $tf ||
		error "can't setstripe"
	$LFS getstripe $tf | grep compress || error "no compression used?"

	b=$(1009e_check zero 0 $((chsz*2/4)) )
	log "initial write - $b"
	(( b < 4 )) || error "too many blocks written - $b"

	b=$(1009e_check urandom 1 1)
	log "initial overwrite 4K @ 4K - $b"
	(( b >= (chsz/4) )) || error "not enough written - $b"

	b=$(1009e_check urandom 2 1)
	log "next overwrite 4K @ 8K - $b"
	(( b >= 1 && b <= pgsz+1 )) || error "written $b"

	b=$(1009e_check urandom 3 1)
	log "next overwrite 4K @ 12K - $b"
	(( b >= 1 && b <= pgsz+1 )) || error "written $b"

	b=$(1009e_check urandom 4 2)
	log "next overwrite 8K @ 16K - $b"
	(( b >= 2 && b <= pgsz+1 )) || error "written $b"
}
run_test 1009e "don't send extra IO if chunk isn't compressed"

test_1010() {
	local orig="/etc/services"
	local tf=$DIR/$tfile
	local checkf=$(mktemp)
	local chsz=64
	local read_ahead_mb

	stack_trap "rm -f $tf"

	# XXX check /etc/services has enough data

	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb"
	$LCTL set_param llite.*.max_read_ahead_mb=0

	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4 --compress-chunk=$chsz $tf ||
		error "can't setstripe"
	$LFS getstripe $tf | grep compress || error "no compression used?"

	# generate a file with a broken chunk
#define OBD_FAIL_OST_CSDC_WRITE_BAD	 0x255
	do_facet ost1 "$LCTL set_param fail_loc=0x80000255"
	dd if=$orig of=$tf bs=${chsz}k conv=fdatasync ||
		error "can't write compressed file"

	# try to read a whole compressed chunk
	# (decompress on the client side)
	echo "read a whole compressed chunk"
	cancel_lru_locks osc
	dd if=$tf of=/dev/null bs=${chsz}k count=1 &&
		error "still can read the broken chunk?"
	rm $tf

	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4 --compress-chunk=$chsz $tf ||
		error "can't setstripe"
	# generate a file with a broken chunk
#define OBD_FAIL_OST_CSDC_WRITE_BAD	 0x255
	do_facet ost1 "$LCTL set_param fail_loc=0x80000255"
	dd if=$orig of=$tf bs=${chsz}k conv=fdatasync ||
		error "can't write compressed file"

	# try to read a partial chunk
	# (decompress on the server side)
	echo "read a partial chunk"
	cancel_lru_locks osc
	dd if=$tf of=/dev/null bs=4k skip=2 count=1 iflag=direct &&
		error "still can read partial chunk"

	# try to overwrite a partial chunk
	echo "overwrite a partial chunk"
	cancel_lru_locks osc
	dd if=/dev/zero of=$tf bs=4k seek=3 count=1 oflag=direct conv=fdatasync,notrunc &&
		error "still can overwrite partial broken chunk"

	# try to overwrite a whole compressed chunk
	echo "overwrite a whole compressed chunk"
	cancel_lru_locks osc
	dd if=/dev/zero of=$tf bs=${chsz}k count=1 conv=fdatasync,notrunc ||
		error "can't overwrite a broken chunk with a good one"

	# XXX: truncate to a middle of a broken chunk
}
run_test 1010 "compression: broken chunks"

test_1011() {
	[ "$SLOW" = "no" ] && skip_env "slow due to lots of IO"
	skip_env "reimplement with fallocate"

	local tf=$DIR/$tfile
	local free=$($LCTL get_param -n osc.*OST0000-osc-f*.kbytesavail)

	$LFS setstripe -c 1 -Eeof -Z lz4:0 --compress-chunk=64 $tf ||
		error "can't set striping"
	stack_trap "rm -f $tf && wait_delete_completed"

	dd if=/dev/zero of=$tf bs=1k || error "dd failed"
	sync
	cancel_lru_locks osc

	local fblocks=$(stat -c %b $tf)
	((fblocks=fblocks/2))
	local left=$($LFS df|awk '/OST0000/{print $4}')
	(( fblocks >= (left-free)*100)) ||
		error "can't fill OST: file in $fblocks, OST had $free, now $left"
	(( left < 1000 )) ||
		error "can't fill OST: file in $fblocks, OST had $free, now $left (2)"
}
run_test 1011 "grants let a compressed file fill OST"

test_1012() {
	local tf=$DIR/$tfile
	local chsz=1024
	local chkf=$(mktemp)
	local tmpf=$(mktemp)

	stack_trap "rm -f $tf $chkf $tmpf"
	$LCTL get_param osc.*.max_pages_per_rpc

	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4:0 --compress-chunk=$chsz $tf ||
		error "can't setstripe"
	$LFS getstripe $tf | grep -q compress || error "no compression used?"
	$LFS getstripe $tf

	dd if=/dev/zero of=$tf bs=1M count=100 conv=fdatasync ||
               error "can't dd"
	dd if=/dev/urandom of=$chkf bs=4k count=1 || error "dd failed"

	ddopt=""
	for ((i=0; i < 128; i++)); do
		(( i == 64 )) && ddopt="conv=fdatasync"
		dd if=$chkf of=$tf bs=4k count=1 seek=$((i*chsz/4)) $ddopt ||
			error "can't dd"
		#[[ $? == 0 ]] || error "can't dd"
	done
	cancel_lru_locks osc

	for ((i=0; i < 65; i++)); do
		dd if=$tf of=$tmpf bs=4k count=1 skip=$((i*chsz/4)) ||
			error "can't read"
		cmp $tmpf $chkf >&/dev/null || {
			cmp $tmpf $chkf | head
			error "don't match @ $i"
		}
	done
	return 0
}
run_test 1012 "check highly-fragmened IO"

test_1013a() {
	local obd_str="obdfilter.$FSNAME-OST0000"
	local types_save=($(do_facet ost1 \
			    $LCTL get_param -n $obd_str.compress_types))

	[[ -n "$types_save" ]] || skip "no OST support for compress_types"

	echo " ** add gzip, delete lzo compression type on OST0000"
	# remount needed after compress_types is reset, so register first
	stack_trap "umount_client $MOUNT; mount_client $MOUNT"
	do_facet ost1 $LCTL set_param -n $obd_str.compress_types=+gzip-lzo
	stack_trap "do_facet ost1 \
		    $LCTL set_param -n $obd_str.compress_types='$types_save'"

	# remount client to get new compression types from OSS
	umount_client $MOUNT
	mount_client $MOUNT

	local obdtypes=$(do_facet ost1 $LCTL get_param $obd_str.compress_types)
	local tgt_name="$FSNAME-OST0000-osc-$($LFS getname -i $MOUNT)"
	local import="osc.$tgt_name.import"
	local types=$($LCTL get_param -n $import | grep compress_types)
	echo " ** $obd_str: $obdtypes"
	echo " ** $import: $types"
	[[ -n "$types" ]] ||
		error "cannot find any compress support on client"
	[[ "$types" =~ "gzip" ]] ||
		error "cannot find gzip compress support on client"
	[[ ! "$types" =~ "lzo" ]] ||
		error "should not have lzo compress support on client"
}
run_test 1013a "compression types negotiation between client and OST"

test_1013b() {
	local obd_str="mdt.$FSNAME-MDT0000"
	local types_save=($(do_facet mds1 \
			    $LCTL get_param -n $obd_str.compress_types))

	if [[ -z $(do_facet mds1 "$LCTL get_param mdt.*.compress_types") ]] &&
	   (( $MDS1_VERSION > $(version_code 2.14.0-ddn128-6-g70133e8f) ||
	      $MDS1_VERSION < $(version_code 2.14.0-ddn88-4-g0d1831c9e) )); then
		# Test compressed *cannot* be created if MDS has no support.
		# The above checks exclude MDS versions where CSDC *layout* was
		# accepted, but before connect flag was added (compress_types).
		$LFS setstripe -E eof -c 1 -Z lzo $DIR/$tfile &&
			error "able to create file without compression"
	fi

	skip "MDT support for compression connect flags is disabled for now"

	[[ -n "$types_save" ]] || skip "no MDT support for compress_types"
	stack_trap "do_facet mds1 \
		    $LCTL set_param mdt.*.compress_types='$types_save'"

	echo " ** add gzip, delete lzo compression type on MDT"
	# remount needed after compress_types is reset, so register first
	stack_trap "umount_client $MOUNT; mount_client $MOUNT"
	do_facet mds1 $LCTL set_param $obd_str.compress_types=+gzip-lzo
	stack_trap "do_facet mds1 \
		    $LCTL set_param -n $obd_str.compress_types='$types_save'"

	# remount client to get new compression types from MDS
	umount_client $MOUNT
	mount_client $MOUNT

	local obdtypes=$(do_facet mds1 $LCTL get_param $obd_str.compress_types)
	local tgt_name="$FSNAME-MDT0000-mdc-$($LFS getname -i $MOUNT)"
	local import="mdc.$tgt_name.import"
	local types=$($LCTL get_param -n $import | grep compress_types)
	echo " ** $obd_str: $obdtypes"
	echo " ** $import: $types"

	[[ -n "$types" ]] ||
		error "cannot find any compress support on client"
	[[ "$types" =~ "gzip" ]] ||
		error "cannot find gzip compress support on client"
	[[ "$types" =~ "lzo" ]] &&
		error "should not have lzo compress support on client"
}
run_test 1013b "compression types negotiation between client and MDT"

test_1013c() {
	local tf=$DIR/$tdir/$tfile

	$LFS setstripe -Z lz4 --compress-level a $tf &&
		error "setstripe '--compress-level a' should failed"
	$LFS setstripe -Z lz4:a $tf &&
		error "setstripe '-Z lz4:a' should failed"
	return 0
}
run_test 1013c "set invalid compress level"

test_1013d() {
	local ost_obd_str="obdfilter.$FSNAME-OST0000"
	local ost_types_save=$(do_facet ost1 \
			       $LCTL get_param -n $ost_obd_str.compress_types)

	[[ -n "$ost_types_save" ]] || skip "no OST support for compress_types"

	# Get client OSC name
	local ost_client_osc="osc.$FSNAME-OST0000-osc-*"

	# remount needed after compress_types is reset, so register first
	stack_trap "umount_client $MOUNT; mount_client $MOUNT"

	# Verify OST compression types consistency
	local ost_server_types=$(do_facet ost1 \
				$LCTL get_param -n $ost_obd_str.compress_types)
	local ost_client_types=$($LCTL get_param -n $ost_client_osc.compress_types)

	echo " ** $ost_obd_str: $ost_server_types"
	echo " ** $ost_client_osc: $ost_client_types"

	[[ "$ost_server_types" == "$ost_client_types" ]] ||
		error "OST compress_types mismatch: server vs client"

	# Test modifying compression types on OST
	echo " ** Modify compression types on OST"

	# Add gzip, remove lzo on OST
	do_facet ost1 $LCTL set_param -n $ost_obd_str.compress_types=+gzip-lzo
	stack_trap "do_facet ost1 \
		$LCTL set_param -n $ost_obd_str.compress_types='$ost_types_save'"

	# Remount client to get new compression types
	umount_client $MOUNT
	mount_client $MOUNT

	# Verify OST changes propagated to client
	ost_server_types=$(do_facet ost1 \
			   $LCTL get_param -n $ost_obd_str.compress_types)
	ost_client_types=$($LCTL get_param -n $ost_client_osc.compress_types)

	echo " ** $ost_obd_str: $ost_server_types"
	echo " ** $ost_client_osc: $ost_client_types"

	[[ "$ost_server_types" == "$ost_client_types" ]] ||
		error "OST compress_types mismatch after change"
	[[ "$ost_client_types" =~ "gzip" ]] ||
		error "OST client missing gzip compression support"
	[[ ! "$ost_client_types" =~ "lzo" ]] ||
		error "OST client should not have lzo compression support"
}
run_test 1013d "verify OST/OSC compression types consistency between client and server"

test_1013e() {
	local mdt_obd_str="mdt.$FSNAME-MDT0000"
	local mdt_types_save=$(do_facet mds1 \
			       $LCTL get_param -n $mdt_obd_str.compress_types)

	[[ -n "$mdt_types_save" ]] || skip "no MDT support for compress_types"

	# Get client MDC name
	local mdt_client_mdc="mdc.$FSNAME-MDT0000-mdc-*"

	# Check if MDC supports compression
	local mdc_flags=$($LCTL get_param -n $mdt_client_mdc.import)
	[[ $mdc_flags =~ connect_flags:.*compressed_file ]] ||
		skip "MDC does not support data compression"

	# remount needed after compress_types is reset, so register first
	stack_trap "umount_client $MOUNT; mount_client $MOUNT"

	# Verify MDT compression types consistency
	local mdt_server_types=$(do_facet mds1 \
				 $LCTL get_param -n $mdt_obd_str.compress_types)
	local mdt_client_types=$($LCTL get_param -n $mdt_client_mdc.compress_types)

	echo " ** $mdt_obd_str: $mdt_server_types"
	echo " ** $mdt_client_mdc: $mdt_client_types"

	[[ "$mdt_server_types" == "$mdt_client_types" ]] ||
		error "MDT compress_types mismatch: server vs client"

	# Test modifying compression types on MDT
	echo " ** Modify compression types on MDT"

	# Add gzip, remove lzo on MDT
	do_facet mds1 $LCTL set_param -n $mdt_obd_str.compress_types=+gzip-lzo
	stack_trap "do_facet mds1 \
		$LCTL set_param -n $mdt_obd_str.compress_types='$mdt_types_save'"

	# Remount client to get new compression types
	umount_client $MOUNT
	mount_client $MOUNT

	# Verify MDT changes propagated to client
	mdt_server_types=$(do_facet mds1 \
			   $LCTL get_param -n $mdt_obd_str.compress_types)
	mdt_client_types=$($LCTL get_param -n $mdt_client_mdc.compress_types)

	echo " ** $mdt_obd_str: $mdt_server_types"
	echo " ** $mdt_client_mdc: $mdt_client_types"

	[[ "$mdt_server_types" == "$mdt_client_types" ]] ||
		error "MDT compress_types mismatch after change"
	[[ "$mdt_client_types" =~ "gzip" ]] ||
		error "MDT client missing gzip compression support"
	[[ ! "$mdt_client_types" =~ "lzo" ]] ||
		error "MDT client should not have lzo compression support"
}
run_test 1013e "verify MDT/MDC compression types consistency between client and server"

test_1014() {
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn128) )) ||
		skip "Need MDS version at least 2.14.0-ddn128"

	$LFS setstripe -Z lz4:3 $DIR/$tfile || error "setstripe -Z failed"
	$LFS setstripe -E eof -Z lz4:3 $DIR/$tfile.2 ||
		error "setstripe -E eof -Z failed"
	$LFS getstripe -Z $DIR/$tfile

	local def=$($LFS getstripe -Z $DIR/$tfile)
	local eof=$($LFS getstripe -Z $DIR/$tfile.2)

	[[ "$def" == "$eof" ]] || error "default '$def' != eof '$eof'"
}
run_test 1014 "add PFL for compressed layout"

test_1015() {
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn153) )) ||
		skip "Need MDS version at least 2.14.0-ddn153"

	test_mkdir -p $DIR/$tdir
	local tf=$DIR/$tdir/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local size1
	local size2

	if [[ ! -f $tmp_hdf ]]; then
		if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
			bzcat $hdf.bz2 > $tmp_hdf
		elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
			cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
			bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
		else
			skip_env "bunzip2 is not installed"
		fi
	fi

	size1=$(du -sk $tmp_hdf | awk '{print $1}')
	echo "original file size: $size1"
	stack_trap "rm -f $tf"

	# use lz4:6 compression to force loading llz4hc module
	$LFS setstripe -E-1 -c1 -Z lz4:6 --compress-chunk=64 $tf ||
		error "set a compress component in $tf failed"
	cp $tmp_hdf $tf
	$TRUNCATE $tf 0
	sync ; sync

	stack_trap "load_module lz4/llz4hc || true"
	rmmod llz4hc

	# llz4hc module is unloaded, so a file can not be compressed to lz4:6
	# and lzo algorithm will be chosen
	cp $tmp_hdf $tf
	sync ; sync
	size2=$(du -sk $tf | awk '{print $1}')
	echo "compressed file size: $size2"

	(( $size2 < $size1 )) ||
		error "lz4:6 ($size2) should be less than lz4:3 ($size1)"
}
run_test 1015 "Change lz4hc to lz4fast on fault"

test_1016() {
	local tf=$DIR/$tfile
	local chkf=$(mktemp)
	local tmpf=$(mktemp)
	local nr=65
	local chsz

	stack_trap "rm -f $tf $chkf $tmpf"
	$LCTL get_param osc.*.max_pages_per_rpc

	# Disable compressibility check which can break test's expectation
	local saved_check_bytes=$($LCTL get_param -n osc.*OST0000*.compress_check_bytes)
	stack_trap "$LCTL set_param osc.*.compress_check_bytes=$saved_check_bytes"
	$LCTL set_param osc.*.compress_check_bytes=32M

	for chsz in 1024 2048 4096; do
		rm -f $tf
		$LFS setstripe -c 1 -E -1 -Z lz4:0 --compress-chunk=$chsz $tf ||
			error "can't setstripe"
		$LFS getstripe $tf | grep compress ||
			error "no compression used?"

		dd if=/dev/zero of=$tf bs=1M count=100 conv=fdatasync ||
		       error "can't dd"
		dd if=/dev/urandom of=$chkf bs=4k count=1

		log "Writing data in fragments"
		ddopt="conv=notrunc"
		for ((i=0; i < $nr; i++)); do
			(( i == (nr-1) )) && ddopt+=",fdatasync"
			dd if=$chkf of=$tf bs=4k count=1 seek=$((i*chsz/4)) \
				$ddopt || error "can't dd with many fragments"
		done
		cancel_lru_locks osc

		log "NOW READ"
		for ((i=0; i < $nr; i++)); do
			dd if=$tf of=$tmpf bs=4k count=1 skip=$((i*chsz/4)) ||
				error "can't read"
			cmp $tmpf $chkf >&/dev/null || error "don't match @ $i"
		done
	done
}
run_test 1016 "check highly-fragmened compression IO"

test_1020() {
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn178) )) ||
		skip "Need MDS version at least 2.14.0-ddn178"

	(( $OST1_VERSION >= $(version_code 2.14.0-ddn178) )) ||
		skip "Need OST >= 2.14.0-ddn178"

	test_mkdir -p $DIR/$tdir
	local tf=$DIR/$tdir/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local source=$tmp_hdf
	local chunksize=128
	local wb_compr=0	# write_bytes_compr
	local wb_incompr=0	# write_bytes_incompr
	local wb_total_compr=0	# write_bytes_compr + write_bytes_incompr
	local wb_raw=0		# write_bytes_raw
	local rb_raw=0		# read_bytes_raw
	local rb_compr=0	# read_bytes_compr
	local r_chunks=0	# read_chunks_compressed
	local sw_compr_chunk=0	# compr_chunks_write_compressed (obdfilter)
	local sr_decompr_ch=0	# compr_chunks_read_decompressed (obdfilter)

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		skip_env "bunzip2 is not installed"
	fi

	debugsave
	$LCTL set_param debug=sec debug_mb=256

	# Disable readahead so reads are not expanded to full chinks
	$LCTL set_param osc.*.rpc_stats=c
	read_ahead_mb=$($LCTL get_param -n llite.*.max_read_ahead_mb)
	$LCTL set_param llite.*.max_read_ahead_mb=0
	stack_trap "$LCTL set_param llite.*.max_read_ahead_mb=$read_ahead_mb" EXIT

	# clear counters
	cancel_lru_locks osc
	cancel_lru_locks mdc
	$LCTL set_param osc."$FSNAME"-OST0000*.stats_compr=0
	do_facet ost1 $LCTL set_param -n obdfilter.*OST0000*.stats_compr=0

	# Simple compressed layout + (OST-0000 and stripe_count == 1)
	$LFS setstripe -i 0 -c 1 -E -1 \
		       -Z lz4:0 --compress-chunk=$chunksize $DIR/$tdir ||
		       error "set a compress component in $DIR/$tdir failed"

	cp -a $source $tf || error "copy $hdf to $tf failed"
	sync
	cancel_lru_locks osc

	wb_compr=$(lctl get_param osc.$FSNAME-OST0000*.stats_compr |
		   awk '/write_bytes_compr:/ { print $2 }')

	wb_incompr=$(lctl get_param osc.$FSNAME-OST0000*.stats_compr |
		     awk '/write_bytes_incompr:/ { print $2 }')

	wb_raw=$(lctl get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_raw:/ { print $2 }')

	# It doesn't matter how many chunks the client sent,
	# it matters how many the server wrote
	sw_compr_chunk=$(do_facet ost1 $LCTL \
			 get_param obdfilter.*OST0000*.stats_compr |
			 awk '/compr_chunks_write_compressed/ { print $7 }')

	dd if=$tf of=/dev/null bs=1M || error "read $tf via dd failed"
	sync

	rb_compr=$(lctl get_param osc.$FSNAME-OST0000*.stats_compr |
		   awk '/read_bytes_compr:/ { print $2 }')

	rb_raw=$(lctl get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/read_bytes_raw:/ { print $2 }')

	r_chunks=$(lctl get_param osc.$FSNAME-OST0000*.stats_compr |
		   awk '/read_chunks_compressed:/ { print $2 }')

	# Sometimes some chunks may be unpacked on the server
	# before being sent to the client side.
	sr_decompr_ch=$(do_facet ost1 $LCTL \
			get_param obdfilter.*OST0000*.stats_compr |
			awk '/compr_chunks_read_decompressed/ { print $7 }')
	# Print stats for debug
	du --block-size=1 $tf
	$LCTL get_param osc.$FSNAME-OST0000*.stats_compr
	do_facet ost1 $LCTL get_param obdfilter.*OST0000*.stats_compr

	wb_compr=$(round_up_to_page "$wb_compr" "$PAGE_SIZE")
	wb_incompr=$(round_up_to_page "$wb_incompr" "$PAGE_SIZE")
	wb_total_compr=$((wb_compr + wb_incompr))
	wb_total_compr=$((wb_total_compr - rb_compr))
	sw_compr_chunk=$((sw_compr_chunk - sr_decompr_ch))

	(( wb_total_compr < PAGE_SIZE )) ||
		error "compr size does not match. '$rb_compr' != '$wb_total_compr'"

	# we still send whole pages to the client
	# this save us ONE WHOLE if PER PAGE SENT
	local page_size=$(getconf PAGE_SIZE)
	(( rb_raw >= wb_raw && (rb_raw - wb_raw) <= page_size )) ||
		error "original size does not match. '$rb_raw' != '$wb_raw'"

	# FIXME
	# r_chunks + 1 should be removed after fixing
	# the "client has to resend compressed tails sometimes
	# (a race between few ptlrpcd)" issue
	(( r_chunks == sw_compr_chunk || r_chunks + 1 == sw_compr_chunk )) ||
		error "num of chunks does not match. '$r_chunks' != '$sw_compr_chunk'"
}
run_test 1020 "Checking compression counters"

test_1021() {
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn149) )) ||
		skip "Need MDS version at least 2.14.0-ddn149"

	test_mkdir -p $DIR/$tdir
	local tf=$DIR/$tdir/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf

	stack_trap "rm -f $tf"
	checkbytes=($($LCTL get_param -n osc.$FSNAME-OST*.compress_check_bytes))
	skipbytes=($($LCTL get_param -n osc.$FSNAME-OST*.compress_skip_bytes))
	ratio=($($LCTL get_param -n osc.$FSNAME-OST*.compress_reduced_ratio))
	stack_trap "$LCTL set_param \
		osc.$FSNAME-OST*.compress_check_bytes=$checkbytes >/dev/null"
	stack_trap "$LCTL set_param \
		osc.$FSNAME-OST*.compress_skip_bytes=$skipbytes >/dev/null"
	stack_trap "$LCTL set_param \
		osc.$FSNAME-OST*.compress_reduced_ratio=$ratio >/dev/null"
	$LCTL set_param osc.$FSNAME-OST*.compress_check_bytes=1M >/dev/null
	$LCTL set_param osc.$FSNAME-OST*.compress_skip_bytes=2M >/dev/null
	$LCTL set_param osc.$FSNAME-OST*.compress_reduced_ratio=16 >/dev/null

	$LFS setstripe -E-1 -c1 -Z lz4:0 --compress-chunk=64 $DIR/$tdir ||
		error "set a compress component in $DIR/$tdir failed"

	$LCTL set_param osc.*.stats_compr=0 >/dev/null

	# write incompressible data
	echo "copy incompressible file ${hdf}.bz2"
	cp -a ${hdf}.bz2 $tf || error "copy ${hdf}.bz2 to $tf failed"
	sync && stat $tf > /dev/null
	sleep 0.5
	compr1=$($LCTL get_param osc.$FSNAME-OST*.stats_compr |
		 awk '/write_bytes_compr:/ {sum=sum+$2} END {print sum}')
	incompr1=$($LCTL get_param osc.$FSNAME-OST*.stats_compr |
		   awk '/write_bytes_incompr:/ {sum=sum+$2} END {print sum}')
	flag1=$($LFS getstripe -v $tf | awk '/lcm_flags:/ {print $2}')

	echo " * after bz2 data write: compr/incompr $compr1/$incompr1"
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn169) )) && {
		[[ $flag1 =~ "incompr" ]] || {
			$LFS getstripe -v $tf
			error "layout flags $flag1 should contain incompr"
		}
	}
	# zip file should not be compressible
	(( compr1 < 4096 )) ||
		error "should not write much compressed data ($compr1)"
	(( incompr1 > compr1 )) ||
		error "should write more incompressible data ($incompr1 < $compr1)"

	# write compressible data
	echo "add compressible data"
	local sz=$(stat -c "%s" $tf)
	((sz=sz/(64*1024)))
	dd if=/dev/zero of=$tf bs=64K seek=$((sz+1)) count=200 conv=notrunc ||
		error "can't append"
	sync && stat $tf > /dev/null
	sleep 0.5
	compr2=$($LCTL get_param osc.$FSNAME-OST*.stats_compr |
		 awk '/write_bytes_compr:/ {sum=sum+$2} END {print sum}')
	incompr2=$($LCTL get_param osc.$FSNAME-OST*.stats_compr |
		   awk '/write_bytes_incompr:/ {sum=sum+$2} END {print sum}')
	flag2=$($LFS getstripe -v $tf | awk '/lcm_flags:/ {print $2}')

	echo " * after plain data write: compr/incompr $((compr2-compr1))/$((incompr2-incompr1))"
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn169) )) && {
		[[ ! $flag2 =~ "incompr" ]] || {
			$LFS getstripe -v $tf
			error "layout flags $flag2 should not contain incompr"
		}
	}
	(( compr2 > 0 )) || error "should write compressed data $compr2"
}
run_test 1021 "change file compressibiblity"

test_1030() {
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn153) )) ||
		skip "Need MDS version at least 2.14.0-ddn153"

	test_mkdir -p $DIR/$tdir
	local tf=$DIR/$tdir/$tfile
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local size1
	local size2
	local tmpf_size
	local old_ccb

	if [[ ! -f $tmp_hdf ]]; then
		if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
			bzcat $hdf.bz2 > $tmp_hdf
		elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
			cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
			bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
		else
			skip_env "bunzip2 is not installed"
		fi
	fi

	stack_trap "rm -f $tf"

	$LFS setstripe -E-1 -c1 -i0 -Z lz4fast:6 --compress-chunk=64 $tf ||
		error "set a compress component in $tf failed"

	local tmpf_size=$(du -sm $tmp_hdf | awk '{print $1}')
	local old_ccb=($($LCTL get_param -n osc.$FSNAME*.compress_check_bytes))

	$LCTL set_param -n osc.*.compress_check_bytes="$((tmpf_size*2))M"
	stack_trap "$LCTL set_param -n osc.*.compress_check_bytes=$old_ccb"

	do_facet ost1 $LCTL set_param -n obdfilter.$FSNAME-OST0000*.stats_compr=0
	$LCTL set_param -n osc.$FSNAME-OST0000*.stats_compr=0
	cp $tmp_hdf $tf
	sync ; sync
	cancel_lru_locks osc
	cancel_lru_locks mdc
	size1=$(du -sk $tf | awk '{print $1}')
	local nocompr=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		awk '/write_bytes_incompr:/{sum=sum+$2}END{print sum}')

	echo "compressed size with lz4fast:6: $size1"
	$LCTL get_param osc.$FSNAME-OST0000*.stats_compr
	do_facet ost1 $LCTL get_param -n obdfilter.$FSNAME-OST0000*.stats_compr
	echo

	$LCTL set_param -n osc.$FSNAME-OST0000*.stats_compr=0
	do_facet ost1 $LCTL set_param -n obdfilter.$FSNAME-OST0000*.stats_compr=0
	$LFS migrate -E eof -c1 -i0 -Z lz4fast:1 $tf || error "migrate failed"
	sync ; sync
	cancel_lru_locks osc
	cancel_lru_locks mdc
	size2=$(du -sk $tf | awk '{print $1}')
	echo "compressed size with lz4fast:1: $size2"
	nocompr2=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		awk '/write_bytes_incompr:/{sum=sum+$2}END{print sum}')

	$LCTL get_param osc.$FSNAME-OST0000*.stats_compr
	do_facet ost1 $LCTL get_param -n obdfilter.$FSNAME-OST0000*.stats_compr

	(( $nocompr == $nocompr2 )) ||
		skip "different volume compressed: $nocompr != $nocompr2"
	(( $size2 < $size1 )) || {
		lsmod
		error "lz4fast:6 ($size2) should be smaller than lz4fast:1 ($size1)"
	}
}
run_test 1030 "Migrate to another compression level"

test_1031() {
	local hdf=$LUSTRE/tests/AMSR_E_L3_DailyOcean_V05_20111003.hdf
	local tmp_hdf=$TMP/$tfile.hdf
	local tf=$DIR/$tdir/$tfile
	local tf2=$DIR2/$tdir/$tfile
	local val

	(( MDS1_VERSION >= $(version_code 2.14.0-ddn169) )) ||
		skip "Need MDS version at least 2.14.0-ddn169"

	test_mkdir -p $DIR/$tdir

	if is_mounted $MOUNT2; then
		umount_client $MOUNT2
		stack_trap "mount_client $MOUNT2" EXIT
	fi

	stack_trap "rm -f $tf $tf2 $tmp_hdf"
	val=$($LCTL get_param -n llite.*.prefer_fallocate_over_compr | head -n1)
	stack_trap "$LCTL set_param llite.*.prefer_fallocate_over_compr=$val"

	# prefer compression over fallocate
	$LCTL set_param llite.*.prefer_fallocate_over_compr=0 ||
		error "setting prefer_fallocate_over_compr to 0 failed"

	# fallocate on compressed file should be refused
	$LFS setstripe -i 0 -c 1 -E eof -Z lzo $tf || "setstripe $tf failed (1)"
	fallocate -l 1048576 $tf && error "fallocate on compr file should fail"

	# prefer fallocate over compr
	$LCTL set_param llite.*.prefer_fallocate_over_compr=1 ||
		error "setting prefer_fallocate_over_compr to 1 failed"

	# fallocate on compressed file should work
	fallocate -l 1048576 $tf || error "fallocate on compr file failed (1)"
	# check incompressible flag was set
	$LFS getstripe -v $tf
	val=$($LFS getstripe -v $tf | awk '/lcm_flags:/ {print $2}')
	[[ $val =~ "incompr" ]] ||
		error "layout flags $val should contain incompr (1)"

	if [[ -f $hdf.bz2 ]] && type -p bzcat >/dev/null; then
		bzcat $hdf.bz2 > $tmp_hdf
	elif [[ -f $hdf.bz2 ]] && type -p bunzip2 >/dev/null; then
		cp $hdf.bz2 $tmp_hdf.bz2 || error "cp $tmp_hdf.bz2"
		bunzip2 $tmp_hdf.bz2 || error "bunzip2 $tmp_hdf.bz2"
	else
		echo "bunzip2 is not installed, skip it"
		return 0
	fi

	# clear compr stats
	$LCTL set_param osc.$FSNAME-OST0000*.stats_compr=clear

	# write to file, should be uncompressed
	dd if=$tmp_hdf of=$tf bs=1M count=1 conv=fsync ||
		error "write to $tf failed (1)"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_raw:/ { print $2 }')
	(( val == 1048576 )) || error "(1) write_bytes_raw $val != 1048576"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_incompr:/ { print $2 }')
	(( val == 1048576 )) || error "(1) write_bytes_incompr $val != 1048576"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_compr:/ { print $2 }')
	(( val == 0 )) || error "(1) write_bytes_compr $val != 0"

	cancel_lru_locks
	cmp -bl -n 1048576 $tmp_hdf $tf || error "$tmp_hdf and $tf differ (1)"

	# check other mount point sees file as incompressible
	mount_client $MOUNT2 || error "mount $MOUNT2 failed"
	$LFS getstripe -v $tf2
	val=$($LFS getstripe -v $tf2 | awk '/lcm_flags:/ {print $2}')
	[[ $val =~ "incompr" ]] ||
		error "layout flags $val should contain incompr (2)"
	umount_client $MOUNT2 || error "umount $MOUT2 failed"
	rm -f $tf || error "rm $tf failed"

	# write data to compressed file before fallocate
	$LFS setstripe -i 0 -c 1 -E eof -Z lzo $tf || "setstripe $tf failed (2)"
	$LCTL set_param osc.$FSNAME-OST0000*.stats_compr=clear
	dd if=$tmp_hdf of=$tf bs=1M count=1 conv=fsync ||
		error "write to $tf failed (2)"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_raw:/ { print $2 }')
	(( val == 1048576 )) || error "(2) write_bytes_raw $val != 1048576"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_incompr:/ { print $2 }')
	(( val == 0 )) || error "(2) write_bytes_incompr $val != 0"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_compr:/ { print $2 }')
	(( val < 1048576 )) || error "(2) write_bytes_compr $val >= 1048576"

	# fallocate and write again
	fallocate -o 1048576 -l 1048576 $tf ||
		error "fallocate on compr file failed (2)"
	# check incompressible flag was set
	$LFS getstripe -v $tf
	val=$($LFS getstripe -v $tf | awk '/lcm_flags:/ {print $2}')
	[[ $val =~ "incompr" ]] ||
		error "layout flags $val should contain incompr (3)"

	$LCTL set_param osc.$FSNAME-OST0000*.stats_compr=clear
	dd if=$tmp_hdf of=$tf bs=1M count=1 skip=1 seek=1 conv=fsync ||
		error "write to $tf failed (3)"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_raw:/ { print $2 }')
	(( val == 1048576 )) || error "(3) write_bytes_raw $val != 1048576"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_incompr:/ { print $2 }')
	(( val == 1048576 )) || error "(3) write_bytes_incompr $val != 1048576"
	val=$($LCTL get_param osc.$FSNAME-OST0000*.stats_compr |
		 awk '/write_bytes_compr:/ { print $2 }')
	(( val == 0 )) || error "(3) write_bytes_compr $val != 0"

	cancel_lru_locks
	cmp -bl -n 2097152 $tmp_hdf $tf || error "$tmp_hdf and $tf differ (2)"

	# deactivate prefer_fallocate_over_compr
	$LCTL set_param llite.*.prefer_fallocate_over_compr=0 ||
		error "deactivating prefer_fallocate_over_compr failed"
	# fallocate on incompr file should always succeed
	fallocate -l 3145728 $tf ||
		error "fallocate on incompr file failed"
}
run_test 1031 "fallocate vs compression"

test_1080() {
	(( MDS1_VERSION >= $(version_code 2.14.0-ddn128) )) ||
		skip "Need MDS version at least 2.14.0-ddn128"

	test_mkdir -p $DIR/$tdir
	local tf=$DIR/$tdir/$tfile
	local tf2=$TMP/$tfile.2
	local compressed=$LUSTRE/tests/compressed.bin
	local broken_header=$TMP/$tfile.4

	# Disable compressibility check which can break test's expectation
	local saved_check_bytes=$($LCTL get_param -n osc.*OST0000*.compress_check_bytes)
	stack_trap "$LCTL set_param osc.*.compress_check_bytes=$saved_check_bytes"
	$LCTL set_param osc.*.compress_check_bytes=32M

	# Use pre-created compressed file
	hexdump -C $compressed | head
	cat $compressed > $tf
	# The next data is needed for hole after first compressed block
	dd if=/dev/urandom of=$tf bs=64k seek=1 count=1
	sync
	cancel_lru_locks osc
	echo 3 > /proc/sys/vm/drop_caches

	# In case the file has no compressed component, it can't be set
	# after the data was written. Without such a component file is not
	# decompressed at reading because there is
	# clpage->cp_comp_type == LL_COMPR_TYPE_NONE check
	# As a workaround, this check is skipped during the testing,
	# if OBD_FAIL_OSC_FORCE_DECOMPR is set
	# define OBD_FAIL_OSC_FORCE_DECOMPR       0x420
	$LCTL set_param fail_loc=0x420
	# Written data already has compression header
	dd if=$tf of=$tf2 bs=64k count=1 || error "reading data"
	hexdump -C $tf2 | head

	# Here is the compression header format to explain offsets
	# struct ll_compr_hdr {
	# __u64 llch_magic:48;     /* LLCH_MAGIC */
	# __u8  llch_header_size;  /* for future extensions */
	# __u8  llch_extra_flags;
	# __u16 llch_flags;
	# __u8  llch_compr_type;    /* LLCH_COMP_GZIP, LLCH_COMP_LZ4, */
	# __u8  llch_compr_level:4, /* per-algorithm mapped level */
	#       llch_chunk_log_bits:4;
	# __u32 llch_compr_size;    /* bytes of compressed data */
	# __u32 llch_reserved;     /* unused, initialize to 0 */
	# __u32 llch_uncompr_csum; /* crc32 of raw data, or 0 */
	# __u32 llch_compr_csum;   /* crc32 of compressed data, or 0 */
	# __u32 llch_hdr_csum;     /* crc32 of magic..compr_csum, or 0 */
	#};

	# set wrong llch_compr_size
	# checksum should fail and chunk copied as is
	cp $compressed $broken_header
	printf '\xff\xff\xff\xff' | dd of=$broken_header bs=1 seek=12 conv=notrunc
	cat $broken_header > $tf
	# The next data is needed for hole after first compressed block
	dd if=/dev/urandom of=$tf bs=64k seek=1 count=1
	sync
	cancel_lru_locks osc
	echo 3 > /proc/sys/vm/drop_caches

	# If the magic is found but most fields are invalid, it implies that the data
	# is likely uncompressed and should be passed through unmodified.
	dd if=$tf of=$tf2 bs=64k count=1 || error "reading data failed(0)"
	hexdump -C $tf2 | head

	# fix checksum, so sanity check fail at wrong header size
	printf '\x88\xb3\xf6\x81' | dd of=$broken_header bs=1 seek=28 conv=notrunc
	cat $broken_header > $tf
	# The next data is needed for hole after first compressed block
	dd if=/dev/urandom of=$tf bs=64k seek=1 count=1
	sync
	cancel_lru_locks osc
	echo 3 > /proc/sys/vm/drop_caches

	# If the magic is valid but some fields are invalid, the reading
	# must fail, because data is corrupted.
	dd if=$tf of=$tf2 bs=64k count=1 && error "reading should fail"
	hexdump -C $tf2 | head

	# Set checksum to 0, so sanity check fails at wrong header size,
	# but chunk is returned as is without error
	printf '\x0\x0\x0\x0' | dd of=$broken_header bs=1 seek=28 conv=notrunc
	cat $broken_header > $tf
	# The next data is needed for hole after first compressed block
	dd if=/dev/urandom of=$tf bs=64k seek=1 count=1
	sync
	cancel_lru_locks osc
	echo 3 > /proc/sys/vm/drop_caches

	# If the magic is 0 and some fields are invalid, it still can be
	# not corrupted chunk but coincidence.
	dd if=$tf of=$tf2 bs=64k count=1 || error "reading data failed(0)"
	hexdump -C $tf2 | head
	$LCTL set_param fail_loc=0x0
}
run_test 1080 "Compression header error tolerance"

test_1081() {
	which dbench > /dev/null 2>&1 || skip_env "No dbench installed"

	local DBENCHDIR=$DIR/$tdir
	mkdir -p $DBENCHDIR
	stack_trap "rm -rf $DBENCHDIR"

	local SPACE=$(df -P $MOUNT | tail -n 1 | awk '{ print $4 }')
	DB_THREADS=$((SPACE / 50000))
	(( $THREADS < $DB_THREADS )) && DB_THREADS=$THREADS

	myUID=$RUNAS_ID
	myGID=$RUNAS_GID
	myRUNAS=$RUNAS
	FAIL_ON_ERROR=false check_runas_id_ret $myUID $myGID $myRUNAS ||
		{ myRUNAS="" && myUID=$UID && myGID=`id -g $USER`; }
	chown $myUID:$myGID $DBENCHDIR

	# enable cache in OSD to help with false failures
	# when we skip writes after replay_barrier, but keep reading
	# for read-modify-write operations
	readcache=$(do_facet ost1 $LCTL get_param -n osd*.*OST0000.read_cache_enable)
	writecache=$(do_facet ost1 $LCTL get_param -n osd*.*OST0000.writethrough_cache_enable)
	stack_trap "do_facet ost1 $LCTL set_param osd*.*OST0000.writethrough_cache_enable=$writecache"
	stack_trap "do_facet ost1 $LCTL set_param osd*.*OST0000.read_cache_enable=$readcache"
	do_facet ost1 $LCTL set_param osd*.*OST0000*.writethrough_cache_enable=1
	do_facet ost1 $LCTL set_param osd*.*OST0000*.read_cache_enable=1

	local pids=""
	local duration="120"
	[[ "$SLOW" == "yes" ]] && duration="240"
	for ((i = 0; i < 2; i++)); do
		mkdir -p $DBENCHDIR/$i
		$LFS setstripe -c -1 -Eeof -Z lz4:0 --compress-chunk=64 \
			$DBENCHDIR/$i || error "can't set striping"
		chown $myUID:$myGID $DBENCHDIR/$i

		$myRUNAS bash rundbench -D $DBENCHDIR/$i $DB_THREADS -t $duration &
		pids="$pids $!"
	done

	local start=$SECONDS
	while (( (SECONDS - start) < duration )); do
		sleep 1
		replay_barrier ost1
		sleep 0.5
		fail ost1
	done

	for i in $pids; do
		wait $i
		rc=$?
		echo "$i finished with $rc"
	done
	return $rc
}
run_test 1081 "failover dbench"

test_1121() {
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn152) )) ||
		skip "Need OST >= 2.14.0-ddn152 for get compr statistics"

	local tf=$DIR/$tdir/$tfile
	local chunksize=128
	local output
	local compressed_objects
	test_mkdir -p "$DIR/$tdir"

	# Clear counters
	do_facet ost1 $LCTL set_param -n obdfilter.$FSNAME-OST0000*.stats_compr=0

	# Simple compressed layout + (OST-0000 and stripe_count == 1)
	$LFS setstripe -i 0 -c 1 -E -1 \
			-Z lz4:0 --compress-chunk=$chunksize $DIR/$tdir ||
			error "set a compress component in $DIR/$tdir failed"

	stack_trap "rm -f $tf $tf.2"
	touch "$tf"
	touch "$tf.2"
	sync
	cancel_lru_locks osc

	output=$(do_facet ost1 \
		 $LCTL get_param obdfilter.$FSNAME-OST0000*.stats_compr)

	# For debug
	ls -loh $DIR
	echo $output
	do_facet ost1 $LCTL get_param obdfilter.$FSNAME-OST*.stats_compr

	compressed_objects=$(echo "$output" |
			     awk '/compressed_objects/ { print $2 }')

	(( $compressed_objects == 2 )) ||
	 	error "expected compressed_objects value 2, got '$compressed_objects'"
}
run_test 1121 "Сhecking compression counters for obj on server side"

#compr_chunks_write_disk   1 samples [reqs] 1 1 1
#compr_bytes_write_disk    1 samples [bytes] 131072 131072 131072
#compr_bytes_write_user    1 samples [bytes] 8192 8192 8192
#compr_chunks_write_compressed 1 samples [reqs] 0 0 0
#compr_chunks_rmw          1 samples [reqs] 1 1 1
#compr_bytes_rmw           1 samples [bytes] 131072 131072 131072
#compr_bytes_rmw_user      1 samples [bytes] 8192 8192 8192

function parse_compr_stats() {
	local awkcmd

	awkcmd='/compr_chunks_write_disk/	{a1=$5}
		/compr_bytes_write_disk/	{a2=$5}
		/compr_bytes_write_user/	{a3=$5}
		/compr_chunks_write_compressed/	{a4=$5}
		/compr_chunks_rmw/		{a5=$5}
		/compr_bytes_rmw/		{a6=$5}
		/compr_bytes_rmw_user/		{a7=$5}
		/compr_chunks_read_disk/	{a8=$5}
		/compr_bytes_read_disk/		{a9=$5}
		/compr_bytes_read_user/		{a10=$5}
		/compr_bytes_read_decompressed/	{a11=$5}
		/compr_chunks_read_decompressed/{a12=$5}
		BEGIN {a1=a2=a3=a4=a5=a6=a7=a8=a9=a10=a11=a12=0}
		END {print "[CHNK_WR_DSK]=" a1, "[BYTE_WR_DSK]=" a2, \
			"[BYTE_WR_USR]=" a3, "[CHNK_WR_COMPR]=" a4, \
			"[CHNK_RMW]=" a5, "[BYTE_RMW]=" a6, \
			"[BYTE_RMW_USR]=" a7, "[CHNK_RD_DSK]=" a8, \
			"[BYTE_RD_DSK]=" a9, "[BYTE_RD_USR]=" a10, \
			"[BYTE_RD_DECOMPR]=" a11, "[CHNK_RD_DECOMPR]=" a12}'

	do_facet $1 $LCTL get_param -n obdfilter.$FSNAME-${2}*.stats_compr |
		awk "$awkcmd"
}

reset_compr_stats() {
	do_facet $1 $LCTL set_param -n obdfilter.$FSNAME-${2}*.stats_compr=0
}

test_1122() {
	(( OST1_VERSION > $(version_code 2.14.0-ddn168) )) ||
		skip "Need OST >= 2.14.0-ddn169 for OST compression stats"

	local tf=$DIR/$tfile
	declare -A stats
	local pgsz=$(getconf PAGESIZE)
	local rc=0

	$LCTL set_param llite.*.enable_compression=1

	local saved_check_bytes=$($LCTL get_param -n osc.*OST0000*.compress_check_bytes)
	stack_trap "$LCTL set_param osc.*.compress_check_bytes=$saved_check_bytes"
	$LCTL set_param osc.*.compress_check_bytes=32M

	$LFS setstripe -c 1 -i 0 -Z lz4:0 --compress-chunk=256 $tf ||
		error "can't set striping"
	stack_trap "rm -f $tf"
	$LFS getstripe $tf | grep -q lcme_compr_chunk_kb.*256 || {
		$LFS getstripe $tf
		error "unexpected chunk size"
	}

	echo "full chunk write"
	reset_compr_stats ost1 OST0000
	dd if=/dev/zero of=$tf bs=1M count=1 conv=fdatasync ||
		error "dd failed"
	eval stats=($(parse_compr_stats ost1 OST0000))
	(( ${stats[CHNK_WR_DSK]} == 4 && ${stats[BYTE_WR_DSK]} == 16384 &&
	   ${stats[BYTE_WR_USR]} == 1024*1024 &&
	   ${stats[CHNK_WR_COMPR]} == 4 && ${stats[CHNK_RMW]} == 0 &&
	   ${stats[BYTE_RMW]} == 0 && ${stats[BYTE_RMW_USR]} == 0 )) || {
		declare -p stats
		echo "bad counters after full chunk write"
		rc=1
	}

	echo "partial chunk overwrite"
	reset_compr_stats ost1 OST0000
	dd if=/dev/zero of=$tf bs=8k count=1 conv=fdatasync,notrunc ||
		error "dd failed"
	eval stats=($(parse_compr_stats ost1 OST0000))
        local usrbt=8192
	(( pgsz > 8192 )) && usrbt=$pgsz
	(( ${stats[CHNK_WR_DSK]} == 1 && ${stats[BYTE_WR_DSK]} == 256*1024 &&
	   ${stats[BYTE_WR_USR]} == $usrbt && ${stats[CHNK_RMW]} == 1 &&
	   ${stats[BYTE_RMW]} == $usrbt && ${stats[BYTE_RMW_USR]} == $usrbt &&
	   ${stats[CHNK_WR_COMPR]} == 0 )) || {
		declare -p stats
		echo "bad counters after partial chunk write"
		rc=1
	}

	echo "tail chunk write"
	$TRUNCATE $tf 0 || error "truncate failed"
	reset_compr_stats ost1 OST0000
	dd if=/dev/zero of=$tf bs=33k count=1 conv=fdatasync,notrunc ||
		error "dd failed"
	eval stats=($(parse_compr_stats ost1 OST0000))
	(( ${stats[CHNK_WR_DSK]} == 1 && ${stats[BYTE_WR_DSK]} == 4096 &&
	   ${stats[BYTE_WR_USR]} == 33*1024 && ${stats[CHNK_RMW]} == 0 &&
	   ${stats[BYTE_RMW]} == 0 && ${stats[BYTE_RMW_USR]} == 0 &&
	   ${stats[CHNK_WR_COMPR]} == 1 )) || {
		declare -p stats
		echo "bad counters after tail chunk write"
		ec=1
	}

	echo "tail chunk overwrite"
	reset_compr_stats ost1 OST0000
	dd if=/dev/zero of=$tf bs=8k count=1 seek=2 conv=fdatasync,notrunc ||
		error "dd failed"
	eval stats=($(parse_compr_stats ost1 OST0000))

	if (( pgsz == 4096 )); then
		(( ${stats[CHNK_WR_DSK]} == 1 && ${stats[BYTE_WR_DSK]} == 36*1024 &&
		   ${stats[BYTE_WR_USR]} == 8192 && ${stats[CHNK_RMW]} == 1 &&
		   ${stats[BYTE_RMW]} == 8192 && ${stats[BYTE_RMW_USR]} == 8192 &&
		   ${stats[CHNK_WR_COMPR]} == 0 )) || {
			declare -p stats
			echo "bad counters after tail chunk overwrite"
			rc=1
		}
	elif (( pgsz == 64*1024 )); then
		# with 64K pages client just sends a full page compressed
		(( ${stats[CHNK_WR_DSK]} == 1 && ${stats[BYTE_WR_DSK]} == 4096 &&
		   ${stats[BYTE_WR_USR]} == 33*1024 && ${stats[CHNK_RMW]} == 0 &&
		   ${stats[BYTE_RMW]} == 0 && ${stats[BYTE_RMW_USR]} == 0 &&
		   ${stats[CHNK_WR_COMPR]} == 1 )) || {
			declare -p stats
			echo "bad counters after tail chunk overwrite"
			rc=1
		}
	else
		echo "unsupported pagesize=$pgsz"
	fi

	echo "counters on read"
	reset_compr_stats ost1 OST0000
	$TRUNCATE $tf 0 || error "truncate failed"
	dd if=/dev/zero of=$tf bs=1M count=1 conv=fdatasync ||
		error "dd failed"
	cancel_lru_locks osc
	dd if=$tf of=/dev/null bs=1M count=1 || error "dd read failed"
	eval stats=($(parse_compr_stats ost1 OST0000))
	(( ${stats[CHNK_RD_DSK]} == 4 && ${stats[BYTE_RD_DSK]} == 16384 &&
	   ${stats[BYTE_RD_USR]} == 1024*1024 &&
	   ${stats[BYTE_RD_DECOMPR]} == 0 && ${stats[CHNK_RD_DECOMPR]} == 0)) || {
		declare -p stats
		echo "bad counters after read"
		rc=1
	}

	echo "incompressible write"
	reset_compr_stats ost1 OST0000
	dd if=/dev/urandom of=$tf bs=128k count=8 conv=fdatasync,notrunc ||
		error "dd failed"
	eval stats=($(parse_compr_stats ost1 OST0000))
	(( ${stats[CHNK_WR_DSK]} == 4 && ${stats[BYTE_WR_DSK]} == 1024*1024 &&
	   ${stats[BYTE_WR_USR]} == 1024*1024 && ${stats[CHNK_RMW]} == 0 &&
	   ${stats[BYTE_RMW]} == 0 && ${stats[BYTE_RMW_USR]} == 0 &&
	   ${stats[CHNK_WR_COMPR]} == 0 )) || {
		declare -p stats
		echo "bad counters after incompressible write"
		rc=1
	}

	echo "compressible overwrite"
	reset_compr_stats ost1 OST0000
	dd if=/dev/zero of=$tf bs=128k count=8 conv=fdatasync,notrunc ||
		error "dd failed"
	eval stats=($(parse_compr_stats ost1 OST0000))
	(( ${stats[CHNK_WR_DSK]} == 4 && ${stats[BYTE_WR_DSK]} == 16*1024 &&
	   ${stats[BYTE_WR_USR]} == 1024*1024 && ${stats[CHNK_RMW]} == 0 &&
	   ${stats[BYTE_RMW]} == 0 && ${stats[BYTE_RMW_USR]} == 0 &&
	   ${stats[CHNK_WR_COMPR]} == 4 )) || {
		declare -p stats
		echo "bad counters after compressible overwrite"
		rc=1
	}

	(( rc == 0 )) || error "bad compression counters"
}
run_test 1122 "check compression stats on server"

test_1123() {
	local tf=$DIR/$tfile
	declare -A stats
	declare -A newstats

	$LFS setstripe -c 1 -i 0 -Z lz4:0 --compress-chunk=128 $tf ||
		error "can't set striping"

	reset_compr_stats ost1 OST0000
	dd if=/dev/zero of=$tf bs=1M count=1 conv=fdatasync ||
		error "dd failed"
	dd if=/dev/zero of=$tf bs=8k count=1 conv=fdatasync,notrunc ||
		error "dd failed"
	dd if=/dev/zero of=$tf bs=33k count=1 conv=fdatasync,notrunc ||
		error "dd failed"
	dd if=/dev/zero of=$tf bs=8k count=1 seek=2 conv=fdatasync,notrunc ||
		error "dd failed"
	eval stats=($(parse_compr_stats ost1 OST0000))
	declare -p stats

	echo "check stats are restored after ost restart"
	do_facet ost1 $LCTL get_param -n obdfilter.$FSNAME-OST0000*.stats_compr
	stop ost1 || error "(2) Fail to stop ost1"
	start ost1 $(ostdevname 1) $OST_MOUNT_OPTS ||
		error "(4) Fail to start ost1"
	eval newstats=($(parse_compr_stats ost1 OST0000))
	local i
	for i in ${!stats[@]}; do
		(( ${stats[$i]} == ${newstats[$i]} )) || {
			echo "before:"
			declare -p stats
			echo "after:"
			declare -p newstats
			error "stats mismatch after restart"
		}
	done
	do_facet ost1 $LCTL get_param -n obdfilter.$FSNAME-OST0000*.stats_compr
}
run_test 1123 "check persistent compression stats on server"

subtest_2000() {
	local tf=$DIR/$tdir/$tfile
	local chunk=$1
	local ulimit_nr
	local oom_nr

	echo "Compress chunk size is $chunk"
	$LFS setstripe -i 0 -c 1 -E -1 -Z lz4 --compress-chunk=$chunk $tf ||
		error "can't setstripe with chunksize $chunk"

	# 70% of RAM but less than 5GB
	count=$((RAMKB*70/100/1024))
	(( count < 5000 )) || count=5000
	$LCTL get_param sptlrpc.page_pools
	dd if=/dev/zero of=$tf bs=1M count=$count conv=fdatasync || true
	$LCTL get_param sptlrpc.page_pools
	dmesg | grep -c OOM
	oom_nr=$(dmesg | grep -c OOM)
	$MEMHOG $((RAMKB*40/100))K
	$LCTL get_param sptlrpc.page_pools
	rm -f $tf || error "rm $tf failed"
	(( $oom_nr == $(dmesg | grep -c OOM) )) || error "OOM happened"
}

test_2000() {
	local chunks=(4096)

	(( $CLIENT_VERSION >= $(version_code 2.14.0-ddn157) )) ||
		skip "Need client >= 2.14.0-ddn157 to get OOM fix"

	test_mkdir -p "$DIR/$tdir"
	stack_trap "rm -rf $DIR/$tdir"

	[[ "$SLOW" == "no" ]] ||
		chunks=(64 128 256 512 1024)
	for i in ${chunks[@]}; do
		subtest_2000 $i
	done
}
run_test 2000 "page_pools shrinker causes OOM"

test_2001() {
	local tf=$DIR/$tfile
	local count_mb=1000
	local chunk_kb=512

	(( $CLIENT_VERSION >= $(version_code 2.14.0-ddn175) )) ||
		skip "Need client >= 2.14.0-ddn175 to get page_pool sync fix"

	debugsave
	stack_trap debugrestore
	$LCTL set_param debug=+sec
	$LCTL set_param osc.*.stats_compr=0
	do_facet ost1 $LCTL set_param obdfilter.$FSNAME-OST0000*.stats_compr=0

	$LFS setstripe -i0 -c1 -Eeof -Z lz4:0 --compress-chunk=$chunk_kb $tf ||
		error "can't setstripe to $tf"
	stack_trap "rm -f $tf"
	dd if=/dev/zero of=$tf bs=1M count=$count_mb conv=fsync ||
		error "dd to $tf failed"
	sync
	cancel_lru_locks osc

	$LCTL get_param osc.$FSNAME-OST0000*.stats_compr
	do_facet ost1 $LCTL get_param obdfilter.$FSNAME-OST0000*.stats_compr
	local w_chunks=$(lctl get_param osc.$FSNAME-OST0000*.stats_compr |
		   awk '/write_chunks_compressible:/ { print $2 }')

	echo "w_chunks $w_chunks"

	local chunk_nbr=$((count_mb * 1024 / chunk_kb))
	((w_chunks > chunk_nbr * 85 / 100)) ||
		error "$tf is not fully compressed: $chunk_nbr != $w_chunks"
}
run_test 2001 "All chunks are compressed"

subtest_2002() {
	local chunk_kb=512
	local tf=$1
	local count_mb=$2
	local skip=$3
	local stats_compr=$FSNAME-OST0000*.stats_compr
	local chunk_compr
	local chunk_incompr

	do_facet ost1 $LCTL set_param obdfilter.$stats_compr=0
	$LCTL set_param osc.*.stats_compr=0

	$LFS setstripe -i0 -c1 -Eeof -Z lz4:0 --compress-chunk=$chunk_kb $tf ||
		error "can't setstripe to $tf"

#define CFS_FAIL_SKIP	0x20000000 /* skip N times then fail */
#define OBD_FAIL_OSC_COMPR_ENOMEM	0x421
	$LCTL set_param fail_loc=$((0x421 | 0x20000000))
	$LCTL set_param fail_val=$skip #skip N chunks

	dd if=/dev/zero of=$tf bs=1M count=$count_mb conv=fsync ||
		error "dd to $tf failed"
	sync
	cancel_lru_locks osc

	$LCTL get_param osc.$stats_compr
	do_facet ost1 $LCTL get_param obdfilter.$stats_compr

	read chunk_compr chunk_incompr <<< $($LCTL get_param osc.$stats_compr |
		awk '/write_chunks_compressible/{printf("%s ",$2)}
		     /write_chunks_incompressible/{printf( "%s", $2)}')
	echo "chunk_compr $chunk_compr chunk_incompr $chunk_incompr"

	local chunk_nbr=$((count_mb * 1024 / chunk_kb))
	((chunk_compr == skip)) ||
		error "chunks_compr:$chunk_compr != skip:$skip"
	((chunk_incompr == chunk_nbr - skip)) ||
		error "chunks_incompr:$chunk_incompr != $((chunk_nbr - skip))"
	$LCTL set_param fail_loc=0 fail_val=0
	rm -f $tf
}

test_2002() {
	local tf=$DIR/$tfile
	local count_mb=20

	(( $CLIENT_VERSION >= $(version_code 2.14.0-ddn179) )) ||
		skip "Need client >= 2.14.0-ddn179 for osc_compress ENOMEM fix"

	stack_trap "rm -f $tf"
	subtest_2002 $tf 10 10
	subtest_2002 $tf 10 13
	subtest_2002 $tf 100 199

	return 0
}
run_test 2002 "Compr stat is valid in case of ENOMEM"

save_qos_threshold() {
	local mdts=$(comma_list $(mdts_nodes))
	local lod_qos_threshold_rr

	lod_qos_threshold_rr=$(do_facet mds1 $LCTL get_param -n \
		lod.$FSNAME-MDT0000-mdtlov.qos_threshold_rr)
	lod_qos_threshold_rr=${lod_qos_threshold_rr%%%}
	echo "save qos threshold $lod_qos_threshold_rr"
	stack_trap "do_nodes $mdts $LCTL set_param -n\
		lod.*.qos_threshold_rr=$lod_qos_threshold_rr"
}

subtest_2020a() {
	local tf1=$DIR/$tfile.1
	local args=$1

	for ((i=0; i<$OSTCOUNT; i++)); do
		local tf=$tf1.$i
		$LFS setstripe $args $tf || error "(3) can't setstripe"
		$LFS getstripe -y $tf
		(( $($LFS getstripe -i $tf) == 1 )) ||
			error "ost1 should be used, setstripe args $args"
		rm -f $tf
	done
}

test_2020a() {
	local tf1=$DIR/$tfile.1
	local osts=$(comma_list $(osts_nodes))
	local mdts=$(comma_list $(mdts_nodes))

	(( $MDS1_VERSION >= $(version_code 2.14.0-ddn190) )) ||
		skip "Need MDS >= 2.14.0-ddn190 to test HDD"

	save_qos_threshold
	set_maxage 1
	set_compr_hdd_policy "skip"

	local old=$(do_nodes $osts \
		    $LCTL get_param osd*.*OST*.nonrotational | tr '\n' ' ')
	stack_trap "do_nodes $osts $LCTL set_param $old"

	# Set all OSTS to be HDD
	do_nodes $osts $LCTL set_param osd*.*OST*.nonrotational=0
	wait_update_facet client "$LCTL get_param osc.$FSNAME*.statfs_state |
				  grep -c 'OST.*]\ f'" 0 ||
		error "can't set HDD"
	sleep 5
	$LFS df -v

	$LFS setstripe -E eof -Z gzip:9 $tf1 || error "Can't create $tf1"
	# Only HDDs - compression should be disabled
	$LFS getstripe -y $tf1 | grep compress &&
		error "Compression is sitll enabled for $tf1"
	rm -f $tf1 || error "Can't remove $tf1"

	# Mark OST0001 as SSD
	do_facet ost2  $LCTL set_param osd*.*OST0001*.nonrotational=1
	wait_update $HOSTNAME \
		"$LFS df -v | awk '/OST0001/ {count += NF} END {print count}'" 7
	sleep 5
	$LFS df -v

	# QOS
	do_facet mds1 $LCTL set_param lod.*.qos_threshold_rr=0
	subtest_2020a "-E eof -Z gzip:9"
	# RR
	do_facet mds1 $LCTL set_param lod.*.qos_threshold_rr=100
	subtest_2020a "-E eof -Z gzip:9"
	# lod_ost_alloc_specific
	subtest_2020a "-E eof -Z gzip:9 -i 0"
	subtest_2020a "-E eof -Z gzip:9 -i 1"

	# lod_alloc_ost_list
	$LFS setstripe -E eof -Z gzip:9 -o 0,1 $tf1 || error "Can't create $tf1"
	$LFS getstripe -y $tf1 | grep compress &&
		error "Compression is still enabled for $tf1"

	return 0
}
run_test 2020a "skip HDDs on compression"

test_2020b() {
	local tf1=$DIR/$tfile.1
	local tf2=$DIR/$tfile.2
	local tf3=$DIR/$tfile.3
	local tf4=$DIR/$tfile.4
	local osts=$(comma_list $(osts_nodes))

	(( $MDS1_VERSION >= $(version_code 2.14.0-ddn190) )) ||
		skip "Need MDS >= 2.14.0-ddn190 to test HDD"

	set_maxage 1
	set_compr_hdd_policy "allow"
	save_qos_threshold

	local old=$(do_nodes $osts \
		    $LCTL get_param osd*.*OST*.nonrotational | tr '\n' ' ')
	stack_trap "do_nodes $osts $LCTL set_param $old"

	# Set all OSTS to be HDD. Compression is expected to be allowed
	do_nodes $osts $LCTL set_param osd*.*OST000*.nonrotational=0
	wait_update_facet client "$LCTL get_param osc.$FSNAME*.statfs_state |
				  grep -c 'OST.*]\ f'" 0 ||
		error "can't set HDD"
	sleep 5
	$LFS df -v

	# QOS
	do_facet mdt1 $LCTL set_param lod.*.qos_threshold_rr=0
	$LFS setstripe -E eof -Z gzip:9 $tf1 || error "Can't create $tf1"
	$LFS getstripe -y $tf1 | grep compress ||
		error "(QOS) no compression used?"

	# RR
	do_facet mds1 $LCTL set_param lod.*.qos_threshold_rr=100
	$LFS setstripe -E eof -Z gzip:9 $tf2 || error "Can't create $tf2"
	$LFS getstripe -y $tf2 | grep compress ||
		error "(RR) no compression used?"

	# lod_ost_alloc_specific
	$LFS setstripe -E eof -Z gzip:9 -c 2 -i 0 $tf3 ||
		error "Can't create $tf3"
	$LFS getstripe -y $tf3 | grep compress ||
		error "(alloc_specific) no compression used?"

	# lod_alloc_ost_list
	$LFS setstripe -E eof -Z gzip:9 -o 0,1 $tf4 || error "Can't create $tf4"
	$LFS getstripe -y $tf4 | grep compress ||
		error "(alloc_ost_list) no compression used?"
}
run_test 2020b "Allow compress to HDD"

test_2020c() {
	local tf1=$DIR/$tfile.1
	local tf2=$DIR/$tfile.2
	local osts=$(comma_list $(osts_nodes))
	local mdts=$(comma_list $(mdts_nodes))
	local pname="hdd_pool"

	(( $MDS1_VERSION >= $(version_code 2.14.0-ddn190) )) ||
		skip "Need MDS >= 2.14.0-ddn190 to test HDD"

	set_maxage 1
	save_qos_threshold
	do_nodes $mdts $LCTL set_param lod.*.qos_threshold_rr=0
	set_compr_hdd_policy "fail"

	local old=$(do_nodes $osts \
		    $LCTL get_param osd*.*OST*.nonrotational | tr '\n' ' ')
	stack_trap "do_nodes $osts $LCTL set_param $old"

	# Set all OSTS to be HDD. Compression is expected to be disabled
	do_nodes $osts $LCTL set_param osd*.*OST000*.nonrotational=0
	wait_update_facet client "$LCTL get_param osc.$FSNAME*.statfs_state |
				  grep -c 'OST.*]\ f'" 0 ||
		error "can't set HDD"
	sleep 5
	$LFS df -v

	# QOS
	$LFS setstripe -E eof -Z gzip:9 $tf1 && error "(QOS) shouldn't allow"
	# RR
	do_facet mds1 $LCTL set_param lod.*.qos_threshold_rr=100
	$LFS setstripe -E eof -Z gzip:9 $tf1 && error "(RR) shouldn't allow"
	# lod_ost_alloc_specific
	$LFS setstripe -E eof -Z gzip:9 -c 2 -i 0 $tf1 &&
		error "(alloc_specific) shouldn't allow"
	# lod_alloc_ost_list
	$LFS setstripe -E eof -Z gzip:9 -o 0,1 $tf1 &&
		error "(alloc_ost_list) shouldn't allow"

	return 0
}
run_test 2020c "Fail on cmpression to HDD"

test_fsx() {
	[[ "$ost1_FSTYPE" == "ldiskfs" ]] || skip "need ldiskfs backend"
	(( $OST1_VERSION >= $(version_code 2.14.0-ddn136) )) ||
		skip "Need MDS >= 2.14.0-ddn135-18-ge2ac71cee2 for partial read"

	export LFS_SETSTRIPE_COMPR_OK=1
	local fsx_layout="${fsx_STRIPEPARAMS:--E eof -c -1 -Z lz4:0 }"
	local testfile=$DIR/f0.fsxfile
	local fsx_size=$SIZE
	local fsx_count=${FSX_COUNT:-1000}
	local space=$(df -P $MOUNT | tail -n 1 | awk '{ print $4 }')

	(( $space >= $fsx_size )) || fsx_size=$((space * 3 / 4))
	local fsx_seed=${FSX_SEED:-$RANDOM}

	check_set_fallocate_or_skip

	rm -f $testfile
	$LFS setstripe $fsx_layout $testfile ||
		error "'setstripe $fsx_layout $testfile' failed"
	$LFS getstripe $testfile | grep -q compress ||
		error "no compression enabled on the testfile"
	stack_trap "rm -f $testfile"

	debugsave
	stack_trap "debugrestore"
	$LCTL set_param debug=0

	$LCTL get_param llite.*.enable_compression

	CMD="$FSX -c 50 -p 1000 -S $fsx_seed -P $TMP -l $fsx_size \
	     -N $((fsx_count * 100)) $FSXOPT $testfile"
	echo "Using: $CMD"
	$CMD || error "fsx failed"

	return 0
}
run_test fsx "let fsx crush our precious"

test_dbench() {
	which dbench > /dev/null 2>&1 || skip_env "No dbench installed"
	local db_threads
	local dbenchdir=$DIR/$tdir
	mkdir -p $dbenchdir
	stack_trap "rm -rf $dbenchdir"

	local space=$(df -P $MOUNT | tail -n 1 | awk '{ print $4 }')
	db_threads=$((space / 200000))
	(( $THREADS >= $db_threads )) || db_threads=$THREADS

	myUID=$RUNAS_ID
	myGID=$RUNAS_GID
	myRUNAS=$RUNAS
	FAIL_ON_ERROR=false check_runas_id_ret $myUID $myGID $myRUNAS ||
		{ myRUNAS="" && myUID=$UID && myGID=`id -g $USER`; }
	chown $myUID:$myGID $dbenchdir

	$LFS setstripe -c -1 -Eeof -Z lz4:0 --compress-chunk=128 $dbenchdir ||
		error "can't set striping"

	debugsave
	stack_trap "debugrestore"
	$LCTL set_param debug=0

	local duration=""
	[[ "$SLOW" == "no" ]] && duration=" -t 120"
	$myRUNAS bash rundbench -D $dbenchdir $db_threads $duration
}
run_test dbench "dbench"

test_iozone() {
	[[ "$SLOW" == "yes" ]] || skip_env "iozone is slow"
	if ! which iozone > /dev/null 2>&1; then
		skip_env "No iozone installed"
		return 0
	fi
	local rsize=${RSIZE:-512}
	local size=$SIZE
	# DIO with compression is slow, let's use smaller sample size
	export O_DIRECT

	local iozdir=$DIR/$tdir
	wait_delete_completed || true
	mkdir -p $iozdir

	# chunk to match default iozone recordsize to reduce number of RMW
	$LFS setstripe -c -1 -Eeof -Z lz4:0 --compress-chunk=512 $iozdir ||
		error "can't set striping"
	$LFS getstripe $iozdir | grep -q compress || skip "no compression set"
	sync

	local min=$(lctl get_param -n osc.*.kbytesavail | sort -n | head -n1)
	local space=$(( OSTCOUNT * min ))
	(( $space >= $size )) || size=$((space * 3 / 4))
	log "min OST has ${min}kB available, using ${size}kB file size"
	local iozone_opts="-w -i 0 -i 1 -i 2 -e -+d -r $rsize"
	local iozfile="$iozdir/iozone"
	local iozlog=$TMP/iozone.log
	# $space was calculated with all OSTs

	debugsave
	stack_trap "debugrestore"
	$LCTL set_param debug=0

	local diosize=$((size / 10))
	(( diosize > 1000 )) || diosize=1000

	myUID=$RUNAS_ID
	myGID=$RUNAS_GID
	myRUNAS=$RUNAS
	FAIL_ON_ERROR=false check_runas_id_ret $myUID $myGID $myRUNAS ||
		{ myRUNAS="" && myUID=$UID && myGID=$(id -g $USER); }
	chown $myUID:$myGID $iozdir
	$myRUNAS iozone $iozone_opts -s $diosize -f $iozfile 2>&1 | tee $iozlog
	tail -1 $iozlog | grep -q complete ||
		{ error "iozone (1) failed" && return 1; }
	rm -f $iozdir/*
	wait_delete_completed || true

	$LCTL set_param -n osc.$FSNAME-OST0000*.stats_compr=0
	do_nodes $(comma_list $(osts_nodes)) \
			$LCTL set_param obdfilter.*.stats_compr=clear

	# check if O_DIRECT support is implemented in kernel
	if [ -z "$O_DIRECT" ]; then
		touch $DIR/f.iozone
		if ! $DIRECTIO write $DIR/f.iozone 0 1; then
			log "SKIP iozone DIRECT IO test"
			O_DIRECT=no
		fi
		rm -f $DIR/f.iozone
		wait_delete_completed || true
	fi
	if [ "$O_DIRECT" != "no" -a "$IOZONE_DIR" != "no" ]; then
		# DIO forced to
		$myRUNAS iozone -I $iozone_opts -s $diosize \
			-f $iozfile.odir 2>&1 | tee $iozlog
		tail -1 $iozlog | grep -q complete ||
			{ error "iozone (2) failed" && return 1; }
		rm -f $iozlog
		wait_delete_completed || true
	fi

	$LCTL get_param osc.$FSNAME-OST0000*.stats_compr
	do_nodes $(comma_list $(osts_nodes)) \
			$LCTL get_param obdfilter.*.stats_compr

	space=$(df -P $MOUNT | tail -n 1 | awk '{ print $4 }')
	local ioz_threads=$((space / size * 2 / 3 ))
	(( $THREADS >= $ioz_threads )) || ioz_threads=$THREADS
	local iozver=$(iozone -v | awk '/Revision:/ {print $3}' | tr -d .)
	if (( "$ioz_threads" > 1 && $iozver >= 3145 )); then
		$LFS setstripe -c -1 -Eeof -Z lz4:0 --compress-chunk=512 $iozdir ||
			error "can't set striping"
		local thread=1

		iozfile=" "
		while (( $thread <= $ioz_threads )); do
		    iozfile="$iozfile $iozdir/iozone.$thread"
		    thread=$((thread + 1))
		done
		$myRUNAS iozone $iozone_opts -s $((size / ioz_threads)) \
			-t $ioz_threads -F $iozfile 2>&1 | tee $iozlog
		tail -1 $iozlog | grep -q complete ||
			{ error "iozone (3) failed" && return 1; }
		rm -f $iozlog
		wait_delete_completed || true
	elif (( $iozver < 3145 )); then
		VER=$(iozone -v | awk '/Revision:/ { print $3 }')
		echo "iozone $VER too old for multi-thread test"
	fi
	$LFS getstripe $iozdir/*
}
run_test iozone "iozone"

complete_test $SECONDS
check_and_cleanup_lustre
declare -a logs=($ONLY)
logs=("${logs[@]/#/$TMP/}")
exit_status "$(echo "${logs[@]/%/.log}")"
