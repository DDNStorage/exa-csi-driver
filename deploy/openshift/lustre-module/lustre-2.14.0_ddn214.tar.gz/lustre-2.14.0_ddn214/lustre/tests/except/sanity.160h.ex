# facet op need_version             jira     space_separated_subtests
mds1    >= 2.14.0-ddn203            EX-3746  160h

