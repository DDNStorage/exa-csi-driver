# subtests to be skipped by older clients with specified server version
#facet op need_version  ticket   subtests
ost1   <= 2.14.0-ddn109 EX-10727 0f
