# facet op need_version             jira     space_separated_subtests
mds1    <  2.14.0-ddn109-5-gcee13e7 LU-14927 0f
client  >  2.14.0-ddn7-4-g09d4f0977 EX-12041 300g
