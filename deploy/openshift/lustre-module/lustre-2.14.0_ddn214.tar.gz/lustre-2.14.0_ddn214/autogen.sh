#!/bin/bash
set -e
pw="$PWD"

# avoid the "modules.order: No such file or directory" failure
touch modules.order

libtoolize -q -f
aclocal -I $pw/config $ACLOCAL_FLAGS
autoheader
automake -a -c
autoconf
